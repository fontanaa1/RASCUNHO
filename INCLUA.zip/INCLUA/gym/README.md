# INCLUA — Movimento é para todo mundo

Aplicação React + Vite com autenticação Supabase.

## Executar localmente

Abra o terminal nesta pasta (`gym`) e execute:

```bash
npm install
Copy-Item .env.example .env.local # PowerShell; no macOS/Linux: cp .env.example .env.local
npm run dev
```

Configure `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` em `.env.local`. Não publique esse arquivo.

## Autenticação Google

Ative Google em Supabase → Authentication → Providers → Google. Configure o OAuth Client ID/Secret no Google Cloud e cadastre o callback `https://SEU-PROJETO.supabase.co/auth/v1/callback`. Em Supabase → Authentication → URL Configuration, adicione a URL local (`http://localhost:5173`) às Redirect URLs. Consulte `AULA09_GOOGLE_OAUTH.md` para o passo a passo completo.

## Primeira etapa entregue

- Splash screen de 5 segundos.
- Login com Google e e-mail/senha.
- Cadastro e confirmação por e-mail.
- Recuperação e redefinição de senha.
- Sessão persistente do Supabase Auth.
- Tela inicial pós-login.
- Tema claro/escuro e layout responsivo.
