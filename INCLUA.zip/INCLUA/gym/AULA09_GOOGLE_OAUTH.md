# Apex Performance — Aula 09: Login com Google e Supabase Auth

## 1. Instalar e configurar localmente

Dentro desta pasta `gym`, execute:

```bash
npm install
```

Crie `.env.local` (na mesma pasta de `package.json`) com:

```env
VITE_SUPABASE_URL=https://SEU_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=SUA_PUBLISHABLE_OU_ANON_KEY
```

Não publique `.env.local` nem credenciais privadas. A chave publishable/anon pode ser usada no frontend; nunca coloque `service_role` ou uma secret key no frontend.

## 2. Configurar Google Cloud

1. No Google Cloud Console, selecione/crie um projeto.
2. Configure a tela de consentimento OAuth como Externo (preencha nome do app e contatos; adicione sua conta como test user enquanto o app estiver em teste).
3. Crie um ID de cliente OAuth do tipo Aplicativo da Web.
4. Em URIs de redirecionamento autorizados, adicione exatamente `https://SEU_PROJECT_REF.supabase.co/auth/v1/callback` (troque pelo Project URL real).
5. Copie o Client ID e Client Secret.

## 3. Configurar Supabase

1. Dashboard → Authentication → Sign In / Providers (ou Providers) → Google.
2. Ative Google e informe Client ID e Client Secret do Google Cloud. Salve.
3. Authentication → URL Configuration: defina Site URL como `http://localhost:5173` durante o desenvolvimento.
4. Em Redirect URLs, adicione `http://localhost:5173/**` ou, se o painel exigir URL exata, `http://localhost:5173`.
5. Se usar outro endereço/porta, cadastre esse endereço também.

## 4. Testar

```bash
npm run dev
```

Abra o endereço mostrado pelo Vite, clique em **Entrar com Google**, conclua o consentimento e confirme que nome, e-mail e foto aparecem no cabeçalho. Clique em **Sair** para testar o logout. No Supabase, confira Authentication → Users para confirmar o registro.

O código usa `signInWithOAuth`, recupera a sessão com `getSession` e acompanha mudanças com `onAuthStateChange`. O redirecionamento configurado no código é `window.location.origin`, adequado ao teste no navegador local. Para OAuth dentro do APK Android, é necessário configurar deep links/redirect scheme do Capacitor e autorizar a URL de retorno correspondente; o fluxo web local não configura isso automaticamente.
