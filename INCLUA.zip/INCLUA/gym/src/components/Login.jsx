import { useState } from 'react';
import { supabase } from '../lib/supabase';

export default function Login() {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin // No mobile, precisaremos ajustar isso depois com deep links
      }
    });
    if (error) {
      alert('Erro ao fazer login: ' + error.message);
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-6">
      <h1 className="text-4xl font-bold text-green-600 mb-2">INCLUA</h1>
      <p className="text-gray-600 mb-8 text-center">Movimento é para todo mundo!</p>
      
      <button
        onClick={handleGoogleLogin}
        disabled={loading}
        className="flex items-center gap-3 bg-white border border-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-sm hover:bg-gray-50 transition-colors disabled:opacity-50"
      >
        {loading ? 'Entrando...' : 'Entrar com Google'}
      </button>
    </div>
  );
}