import { useEffect, useState, useRef } from 'react'
import { supabase } from './lib/supabaseClient'
import './App.css'

const SPLASH_DURATION = 2500

export default function App() {
  const [stage, setStage] = useState('splash')
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [theme, setTheme] = useState(() => localStorage.getItem('inclua-theme') || 'dark')
  const [mode, setMode] = useState('login')
  const [currentTab, setCurrentTab] = useState('home')

  // Auth States
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  // Occurrence States
  const [occurrenceCategory, setOccurrenceCategory] = useState('equipment')
  const [occurrenceDesc, setOccurrenceDesc] = useState('')
  const [occurrenceLocation, setOccurrenceLocation] = useState('')

  // Stats States
  const [totalWorkouts, setTotalWorkouts] = useState(0)
  const [totalHits, setTotalHits] = useState(0)

  // Profile States
  const [weight, setWeight] = useState('')
  const [height, setHeight] = useState('')
  const [hasVisual, setHasVisual] = useState(false)
  const [hasMobility, setHasMobility] = useState(false)
  const [hasHearing, setHasHearing] = useState(false)
  const [hasIntellectual, setHasIntellectual] = useState(false)

  // Schedule States
  const [classes, setClasses] = useState([])
  const [myBookings, setMyBookings] = useState([])
  const [selectedClass, setSelectedClass] = useState(null) // NOVO: Para abrir o modal de detalhes da aula

  // Workout States
  const [workouts, setWorkouts] = useState([])
  const [selectedWorkout, setSelectedWorkout] = useState(null)
  const [exercises, setExercises] = useState([])
  const [selectedExercise, setSelectedExercise] = useState(null)
  const [adaptations, setAdaptations] = useState([])
  const [showAdaptation, setShowAdaptation] = useState(false)
  const [expandedAdaptation, setExpandedAdaptation] = useState(null)

  // Active Workout States
  const [isWorkoutActive, setIsWorkoutActive] = useState(false)
  const [workoutTimer, setWorkoutTimer] = useState(0)
  const [completedExercises, setCompletedExercises] = useState([])
  const timerRef = useRef(null)

  // CRUD States
  const [newWorkoutName, setNewWorkoutName] = useState('')
  const [newWorkoutDesc, setNewWorkoutDesc] = useState('')
  const [newWorkoutCover, setNewWorkoutCover] = useState('')
  const [isCreatingWorkout, setIsCreatingWorkout] = useState(false)
  const [editingWorkoutId, setEditingWorkoutId] = useState(null)

  const [isAddingExercise, setIsAddingExercise] = useState(false)
  const [catalogList, setCatalogList] = useState([])
  const [filterGroup, setFilterGroup] = useState('Todos')
  const [selectedCatalogEx, setSelectedCatalogEx] = useState(null)
  const [newExSets, setNewExSets] = useState('3')
  const [newExReps, setNewExReps] = useState('12 repetições')
  const [newExRest, setNewExRest] = useState('60')

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('inclua-theme', theme)
  }, [theme])

  // Lógica do Cronômetro
  useEffect(() => {
    if (isWorkoutActive) {
      timerRef.current = setInterval(() => setWorkoutTimer(prev => prev + 1), 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isWorkoutActive]);

  // Lógica de Splash e Autenticação
  useEffect(() => {
    let alive = true
    const startedAt = Date.now()
    
    const reveal = (session) => {
      if (!alive) return
      setUser(session?.user ?? null)
      
      const remaining = Math.max(0, SPLASH_DURATION - (Date.now() - startedAt))
      window.setTimeout(() => {
        if (alive) setStage(session?.user ? 'home' : 'auth')
      }, remaining)
    }

    supabase.auth.getSession().then(({ data }) => reveal(data?.session))
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!alive) return
      setUser(session?.user ?? null)
      if (stage !== 'splash') {
        if (session?.user) setStage('home')
        else setStage('auth')
      }
    })

    return () => { alive = false; subscription.unsubscribe() }
  }, [stage])

  useEffect(() => {
    if (user) {
      supabase.from('profiles').select('*').eq('id', user.id).single().then(({ data }) => { if (data) setProfile(data) })
      supabase.from('student_details').select('*').eq('user_id', user.id).single().then(({ data }) => {
        if (data) {
          setWeight(data.weight || ''); setHeight(data.height || '')
          setHasVisual(data.has_visual_disability || false); setHasMobility(data.has_mobility_disability || false)
          setHasHearing(data.has_hearing_disability || false); setHasIntellectual(data.has_intellectual_disability || false)
        }
      })
      fetchWorkouts();
      fetchStats();
      fetchSchedule();
    } else {
      setProfile(null); setCurrentTab('home'); setWorkouts([]); setClasses([]); setMyBookings([])
    }
  }, [user])

  async function fetchWorkouts() {
    const { data } = await supabase.from('workouts').select('*').or(`user_id.eq.${user.id},user_id.is.null`).order('created_at', { ascending: false });
    if (data) setWorkouts(data)
  }

  async function fetchStats() {
    const { count: wCount } = await supabase.from('workout_logs').select('*', { count: 'exact', head: true }).eq('user_id', user.id);
    setTotalWorkouts(wCount || 0);
    const { count: hCount } = await supabase.from('safety_reports').select('*', { count: 'exact', head: true }).eq('reporter_id', user.id);
    setTotalHits(hCount || 0);
  }

  // --- FUNÇÕES DA AGENDA ---
  async function fetchSchedule() {
    const { data: classesData } = await supabase.from('gym_classes').select('*').order('created_at');
    if (classesData) setClasses(classesData);

    const { data: bookingsData } = await supabase.from('class_bookings').select('*').eq('user_id', user.id);
    if (bookingsData) setMyBookings(bookingsData);
  }

  async function bookClass(classId) {
    setBusy(true);
    const { error } = await supabase.from('class_bookings').insert([{ user_id: user.id, class_id: classId }]);
    if (error) alert("Erro ao agendar: " + error.message);
    else {
      fetchSchedule();
      setSelectedClass(null); // Fecha o modal após agendar
    }
    setBusy(false);
  }

  async function cancelBooking(bookingId, classId) {
    setBusy(true);
    const { error } = await supabase.from('class_bookings').delete().eq('id', bookingId);
    if (error) alert("Erro ao cancelar: " + error.message);
    else {
      fetchSchedule();
      setSelectedClass(null); // Fecha o modal após cancelar
    }
    setBusy(false);
  }

  function clearFeedback() { setError(''); setMessage('') }

  // --- AUTH & PROFILE ---
  async function submitEmail(e) {
    e.preventDefault(); clearFeedback(); setBusy(true)
    if (mode === 'signup') {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: name } } })
      if (error) setError(error.message)
      else if (data.session) { setUser(data.user); setStage('home') }
      else { setMessage('Confira seu e-mail.'); setMode('login') }
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setError(error.message)
      else { setUser(data.user); setStage('home') }
    }
    setBusy(false)
  }

  async function signInGoogle() {
    clearFeedback(); setBusy(true)
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin } })
    if (error) { setError(error.message); setBusy(false) }
  }

  async function signOut() {
    setBusy(true); const { error } = await supabase.auth.signOut()
    if (!error) { setUser(null); setStage('auth'); setMode('login'); setCurrentTab('home'); clearFeedback() }
    setBusy(false)
  }

  async function recoverPassword() {
    if (!email) { setError("Digite seu e-mail para recuperar a senha."); return; }
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
    if (error) setError(error.message);
    else setMessage("E-mail de recuperação enviado!");
    setBusy(false);
  }

  async function saveStudentDetails(e) {
    e.preventDefault(); clearFeedback(); setBusy(true)
    const { error } = await supabase.from('student_details').upsert({
      user_id: user.id, weight: parseFloat(weight) || null, height: parseInt(height) || null,
      has_visual_disability: hasVisual, has_mobility_disability: hasMobility, has_hearing_disability: hasHearing, has_intellectual_disability: hasIntellectual
    })
    if (error) setError(error.message); else setMessage('Informações salvas!')
    setBusy(false)
  }

  // --- WORKOUT CRUD ---
  async function saveWorkout(e) {
    e.preventDefault(); setBusy(true);
    const workoutData = { 
      name: newWorkoutName, 
      description: newWorkoutDesc,
      cover_url: newWorkoutCover || null
    };

    if (editingWorkoutId) {
      await supabase.from('workouts').update(workoutData).eq('id', editingWorkoutId)
    } else {
      await supabase.from('workouts').insert([{ ...workoutData, user_id: user.id }])
    }
    setNewWorkoutName(''); setNewWorkoutDesc(''); setNewWorkoutCover(''); setIsCreatingWorkout(false); setEditingWorkoutId(null);
    fetchWorkouts(); setBusy(false);
  }

  async function deleteWorkout(id) {
    if (!window.confirm("Excluir este treino?")) return;
    await supabase.from('workouts').delete().eq('id', id);
    fetchWorkouts();
  }

  async function openWorkout(workout) {
    setSelectedWorkout(workout)
    setCurrentTab('workout-details')
    setIsAddingExercise(false)
    setIsWorkoutActive(false) 
    setWorkoutTimer(0)
    setCompletedExercises([])
    const { data } = await supabase.from('exercises').select('*').eq('workout_id', workout.id)
    if (data) setExercises(data)
  }

  // --- EXERCISE CATALOG & ACTIVE WORKOUT ---
  async function openCatalog() {
    setIsAddingExercise(true);
    if (catalogList.length === 0) {
      const { data } = await supabase.from('exercise_catalog').select('*').order('name');
      if (data) setCatalogList(data);
    }
  }

  async function confirmAddExercise(e) {
    e.preventDefault(); setBusy(true);
    await supabase.from('exercises').insert([{
      workout_id: selectedWorkout.id, name: selectedCatalogEx.name, muscle_group: selectedCatalogEx.muscle_group,
      media_url: selectedCatalogEx.media_url, sets: parseInt(newExSets), reps: newExReps, rest_time: parseInt(newExRest)
    }])
    setIsAddingExercise(false); setSelectedCatalogEx(null);
    const { data } = await supabase.from('exercises').select('*').eq('workout_id', selectedWorkout.id)
    if (data) setExercises(data)
    setBusy(false);
  }

  async function openExercise(exercise) {
    setSelectedExercise(exercise); setShowAdaptation(false); setExpandedAdaptation(null)
    const { data } = await supabase.from('exercise_adaptations').select('*').eq('exercise_id', exercise.id)
    if (data) setAdaptations(data)
  }

  function toggleExerciseCheck(exId) {
    setCompletedExercises(prev => prev.includes(exId) ? prev.filter(id => id !== exId) : [...prev, exId]);
  }

  async function finishWorkout() {
    if (!window.confirm("Deseja finalizar este treino?")) return;
    setBusy(true);
    const { error } = await supabase.from('workout_logs').insert([{ user_id: user.id, workout_id: selectedWorkout.id }]);
    if (error) alert("Erro: " + error.message);
    else {
      alert("Treino concluído! Bom trabalho.");
      setIsWorkoutActive(false); setCurrentTab('home'); fetchStats();
    }
    setBusy(false);
  }

  // --- OCORRÊNCIAS ---
  async function submitOccurrence(e) {
    e.preventDefault(); clearFeedback(); setBusy(true)
    const { error } = await supabase.from('safety_reports').insert([{ reporter_id: user.id, category: occurrenceCategory, description: occurrenceDesc, location_description: occurrenceLocation }])
    if (error) setError(error.message)
    else {
      setMessage('Ocorrência registrada com sucesso!')
      setOccurrenceDesc(''); setOccurrenceLocation('')
      setTimeout(() => { setCurrentTab('home'); clearFeedback() }, 2000)
    }
    setBusy(false)
  }

  const formatTime = (totalSeconds) => {
    const h = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const s = (totalSeconds % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  }

  const isStaff = profile?.role === 'admin' || profile?.role === 'employee'
  const firstName = profile?.full_name?.split(' ')[0] || user?.user_metadata?.full_name?.split(' ')[0] || user?.email?.split('@')[0] || 'por aqui'
  const userAvatar = user?.user_metadata?.avatar_url

  if (stage === 'splash') return (
    <main className="splash-screen">
      <div className="splash-orbit orbit-one" /><div className="splash-orbit orbit-two" />
      <div className="brand-lockup splash-lockup"><span className="brand-symbol"><span /><span /><span /></span><span className="brand-word">INCLUA<span className="brand-period">.</span></span></div>
      <p className="splash-tagline">MOVIMENTO É PARA TODO MUNDO.</p>
      <div className="splash-bottom">
        <span className="loading-line"><i /></span>
        <span>CARREGANDO</span>
      </div>
    </main>
  )

  if (stage === 'auth') return (
    <main className="auth-layout">
      <section className="auth-showcase">
        <div className="showcase-glow" />
        <header className="showcase-header"><Brand /></header>
        <div className="showcase-copy">
          <h1>Seu movimento.<br /><em>Seu espaço.</em></h1>
        </div>
      </section>

      <section className="auth-panel">
        <div className="mobile-auth-header">
          <Brand />
          <div className="mobile-auth-text">
            <h1>Seu movimento.<br /><em>Seu espaço.</em></h1>
            <p>Mais segurança, acessibilidade e inclusão na sua academia.</p>
          </div>
        </div>

        <div className="auth-card">
          <button className="google-signin" onClick={signInGoogle} disabled={busy}>
            <GoogleMark /> Continuar com Google
          </button>
          
          <div className="auth-divider"><span />OU<span /></div>

          <form className="auth-form" onSubmit={submitEmail}>
            {mode === 'signup' && <input value={name} onChange={e=>setName(e.target.value)} placeholder="Nome completo" required />}
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="E-mail" required />
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Senha" required />
            {error && <div className="feedback feedback-error">{error}</div>}
            {message && <div className="feedback feedback-success">{message}</div>}
            <button className="submit-button" type="submit">{mode === 'signup' ? 'Criar conta' : 'Entrar'}</button>
          </form>

          <div className="auth-links">
            <button onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')}>
              {mode === 'signup' ? 'Já tenho conta' : 'Criar conta'}
            </button>
            <button onClick={recoverPassword}>Recuperar senha</button>
          </div>
        </div>

        <div className="mobile-auth-footer">
          <button className="accessibility-btn"><span>♿</span> Acessibilidade</button>
        </div>
      </section>
    </main>
  )

  // ================= APP PRINCIPAL LOGADO =================
  return (
    <div className="app-layout">
      <aside className="sidebar-nav">
        <Brand />
        <NavItems currentTab={currentTab} setCurrentTab={setCurrentTab} isStaff={isStaff} isSidebar={true} />
      </aside>

      <main className="app-main-content">
        {!isWorkoutActive && (
          <header className="welcome-header" style={{ height: '70px', marginBottom: '20px' }}>
            <div className="mobile-brand"><Brand /></div>
            <div className="welcome-actions" style={{ marginLeft: 'auto' }}>
              <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☼' : '☾'}</button>
              <button className="profile-chip" onClick={signOut}>
                {userAvatar ? <img src={userAvatar} alt="" /> : <span className="profile-initial">{firstName[0]}</span>}
                <span>{firstName}</span>
              </button>
            </div>
          </header>
        )}

        {/* ABA: HOME */}
        {currentTab === 'home' && !isWorkoutActive && (
          <div className="dashboard-grid">
            <section>
              <div className="dashboard-greeting">
                <div className="welcome-kicker"><i /> CONTA CONECTADA</div>
                <h1>Bem-vindo(a),<br /><em>{firstName}.</em></h1>
                <p className="welcome-lead">Seu espaço para treinar com segurança e acessibilidade.</p>
              </div>
              
              <div className="status-card">
                <span className="status-icon"><IconShield /></span>
                <div><h3>Academia Segura</h3><p>Tudo funcionando bem!</p></div>
              </div>

              <div className="stat-grid">
                <div className="stat-circle-container">
                  <div className="stat-circle">{totalWorkouts}</div>
                  <span className="stat-label-circle">Treinos feitos</span>
                </div>
                <div className="stat-circle-container">
                  <div className="stat-circle">{totalHits}</div>
                  <span className="stat-label-circle">Hits feitos</span>
                </div>
              </div>

              <h3 style={{ margin: '30px 0 15px' }}>Treinos Disponíveis</h3>
              {workouts.length > 0 ? workouts.slice(0, 3).map(w => (
                <div key={w.id} className="workout-card" onClick={() => openWorkout(w)}>
                  <div style={{ width: '48px', height: '48px', borderRadius: '10px', overflow: 'hidden', flexShrink: 0, background: 'var(--panel-2)', display: 'grid', placeItems: 'center', color: 'var(--accent)' }}>
                    {w.cover_url ? (
                      <img src={w.cover_url} alt={w.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <IconDumbbell />
                    )}
                  </div>
                  <div style={{ flex: 1 }}>
                    <h4 style={{ margin: 0, fontSize: '15px' }}>{w.name}</h4>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'var(--muted)' }}>{w.description}</p>
                  </div>
                  <span style={{ color: 'var(--muted)' }}>→</span>
                </div>
              )) : <p style={{ color: 'var(--muted)' }}>Nenhum treino disponível.</p>}
            </section>

            <aside>
              <div style={{ marginBottom: '15px' }}>
                <h3 style={{ margin: 0, fontSize: '18px' }}>Academias Próximas</h3>
                <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'var(--muted)' }}>Encontre a academia mais próxima de você!</p>
              </div>

              <div className="map-wrapper" style={{ padding: 0, overflow: 'hidden', height: '260px' }}>
                <iframe
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                  src="https://maps.google.com/maps?q=academias%20proximas&t=&z=13&ie=UTF8&iwloc=&output=embed"
                ></iframe>
              </div>

              <button onClick={() => setCurrentTab('new-occurrence')} className="submit-button" style={{ width: '100%', background: 'transparent', border: '1px solid var(--accent)', color: 'var(--accent)' }}>
                RELATAR OCORRÊNCIA
              </button>
            </aside>
          </div>
        )}

        {/* ABA: AGENDA DE AULAS */}
        {currentTab === 'schedule' && !isWorkoutActive && (
          <section>
            <div style={{ marginBottom: '30px' }}>
              <h1 style={{ fontSize: '32px', margin: 0 }}>Nossa <em style={{color:'var(--accent)'}}>Agenda.</em></h1>
              <p style={{ color: 'var(--muted)', margin: '5px 0 0' }}>Clique em uma turma para ver os detalhes e se inscrever.</p>
            </div>

            <div style={{ display: 'flex', gap: '20px', flexDirection: 'column' }}>
              {classes.map(c => {
                const isBooked = myBookings.some(b => b.class_id === c.id);
                
                return (
                  <div key={c.id} onClick={() => setSelectedClass(c)} style={{ background: 'var(--panel)', border: isBooked ? '1px solid var(--accent)' : '1px solid var(--line)', borderRadius: '12px', overflow: 'hidden', cursor: 'pointer', transition: '0.2s' }}>
                    <div style={{ padding: '20px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '15px' }}>
                        <div>
                          <h3 style={{ margin: 0, fontSize: '18px', color: isBooked ? 'var(--accent)' : 'var(--text)' }}>{c.name}</h3>
                          <p style={{ margin: '4px 0 0', fontSize: '13px', color: 'var(--muted)' }}>Prof. {c.instructor}</p>
                        </div>
                        {c.is_accessible && (
                          <span style={{ background: 'var(--panel-2)', color: 'var(--accent)', fontSize: '10px', fontWeight: 'bold', padding: '4px 8px', borderRadius: '4px' }}>♿ INCLUSIVO</span>
                        )}
                      </div>

                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '13px', color: 'var(--text)' }}>
                        <div style={{ display: 'flex', gap: '15px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <IconCalendar /> {c.schedule}
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <IconUser /> {c.spots_available} vagas
                          </div>
                        </div>
                        {isBooked && <span style={{ fontSize: '11px', color: 'var(--accent)', fontWeight: 'bold' }}>Inscrito ✓</span>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* MODAL DE DETALHES DA AULA (NOVO) */}
        {selectedClass && (
          <div className="adaptation-overlay" onClick={() => setSelectedClass(null)}>
            <div className="adaptation-content" onClick={e => e.stopPropagation()}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h2 style={{ margin: 0, fontSize: '24px' }}>{selectedClass.name}</h2>
                <button onClick={() => setSelectedClass(null)} style={{ background: 'transparent', border: 'none', color: 'var(--muted)', fontSize: '20px', cursor: 'pointer' }}>✕</button>
              </div>
              
              <div style={{ display: 'flex', gap: '15px', marginBottom: '20px', flexWrap: 'wrap' }}>
                <span style={{ background: 'var(--panel-2)', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}><IconUser /> Prof. {selectedClass.instructor}</span>
                <span style={{ background: 'var(--panel-2)', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}><IconCalendar /> {selectedClass.schedule}</span>
                <span style={{ background: 'var(--panel-2)', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '6px', color: selectedClass.spots_available > 0 ? 'var(--success)' : 'var(--danger)' }}>{selectedClass.spots_available} vagas disponíveis</span>
              </div>

              <div style={{ marginBottom: '30px' }}>
                <h4 style={{ margin: '0 0 8px' }}>Sobre a aula</h4>
                <p style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--muted)', margin: 0 }}>
                  {selectedClass.description || "Nenhuma descrição detalhada disponível para esta turma."}
                </p>
              </div>

              {selectedClass.is_accessible && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', background: 'color-mix(in srgb, var(--accent) 10%, transparent)', padding: '15px', borderRadius: '10px', marginBottom: '20px', border: '1px solid color-mix(in srgb, var(--accent) 30%, transparent)' }}>
                  <span style={{ fontSize: '24px' }}>♿</span>
                  <div>
                    <h4 style={{ margin: 0, color: 'var(--accent)', fontSize: '14px' }}>Aula Inclusiva</h4>
                    <p style={{ margin: 0, fontSize: '12px', color: 'var(--text)' }}>Esta turma possui adaptações e suporte para pessoas com deficiência.</p>
                  </div>
                </div>
              )}

              {(() => {
                const booking = myBookings.find(b => b.class_id === selectedClass.id);
                const isBooked = !!booking;
                const isFull = selectedClass.spots_available <= 0 && !isBooked;

                return isBooked ? (
                  <button 
                    onClick={() => cancelBooking(booking.id, selectedClass.id)}
                    className="submit-button" 
                    style={{ width: '100%', background: 'transparent', border: '1px solid var(--danger)', color: 'var(--danger)', height: '50px', fontSize: '15px' }}
                  >
                    Cancelar Inscrição
                  </button>
                ) : (
                  <button 
                    onClick={() => bookClass(selectedClass.id)}
                    disabled={isFull || busy}
                    className="submit-button" 
                    style={{ width: '100%', height: '50px', fontSize: '15px', opacity: isFull ? 0.5 : 1 }}
                  >
                    {isFull ? 'Turma Lotada' : 'Confirmar Inscrição'}
                  </button>
                );
              })()}
            </div>
          </div>
        )}

        {/* ABA: LISTA DE TREINOS */}
        {currentTab === 'workouts' && !isWorkoutActive && (
          <section>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h1 style={{ fontSize: '32px', margin: 0 }}>Meus <em style={{color:'var(--accent)'}}>Treinos.</em></h1>
              {!isCreatingWorkout && (
                <button onClick={() => { setIsCreatingWorkout(true); setEditingWorkoutId(null); setNewWorkoutName(''); setNewWorkoutDesc(''); setNewWorkoutCover(''); }} className="submit-button" style={{ width: 'auto', padding: '0 20px', margin: 0 }}>
                  + Novo
                </button>
              )}
            </div>

            {isCreatingWorkout && (
              <form onSubmit={saveWorkout} className="auth-form" style={{ background: 'var(--panel-2)', padding: '20px', borderRadius: '12px', marginBottom: '30px', border: '1px solid var(--line)' }}>
                <h3 style={{ margin: 0 }}>{editingWorkoutId ? 'Editar Treino' : 'Criar Novo Treino'}</h3>
                <label>Nome do Treino<input value={newWorkoutName} onChange={e => setNewWorkoutName(e.target.value)} placeholder="Ex: Treino de Sábado" required /></label>
                <label>Descrição<input value={newWorkoutDesc} onChange={e => setNewWorkoutDesc(e.target.value)} placeholder="Ex: Foco em Cardio • 30 min" required /></label>
                <label>Link da Foto de Capa (Opcional)<input value={newWorkoutCover} onChange={e => setNewWorkoutCover(e.target.value)} placeholder="https://..." /></label>
                <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                  <button className="submit-button" type="submit" disabled={busy} style={{ flex: 1 }}>{editingWorkoutId ? 'Salvar' : 'Criar'}</button>
                  <button type="button" onClick={() => setIsCreatingWorkout(false)} className="submit-button" style={{ flex: 1, background: 'transparent', border: '1px solid var(--line)', color: 'var(--text)' }}>Cancelar</button>
                </div>
              </form>
            )}

            {workouts.length > 0 ? workouts.map(w => (
              <div key={w.id} className="workout-card" style={{ flexDirection: 'column', alignItems: 'stretch', padding: 0, overflow: 'hidden' }}>
                
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', background: 'var(--panel-2)', borderBottom: '1px solid var(--line)' }}>
                  {w.user_id === null ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                       <div className="brand-symbol" style={{ width: 24, height: 24, padding: 3, transform: 'none', borderColor: 'var(--accent)' }}><span/><span/><span/></div>
                       <span style={{ fontSize: '11px', fontWeight: 'bold', color: 'var(--accent)' }}>INCLUA Oficial</span>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      {userAvatar ? <img src={userAvatar} alt="" style={{ width: '24px', height: '24px', borderRadius: '50%' }} /> : <div className="profile-initial" style={{ width: '24px', height: '24px', fontSize: '10px' }}>{firstName[0]}</div>}
                      <span style={{ fontSize: '11px', fontWeight: 'bold' }}>{firstName}</span>
                    </div>
                  )}
                  {w.user_id === user.id && (
                    <div style={{ display: 'flex', gap: '12px' }}>
                      <button onClick={(e) => { e.stopPropagation(); setNewWorkoutName(w.name); setNewWorkoutDesc(w.description); setNewWorkoutCover(w.cover_url || ''); setEditingWorkoutId(w.id); setIsCreatingWorkout(true); }} style={{ background: 'transparent', border: 'none', color: 'var(--muted)', fontSize: '11px', cursor: 'pointer' }}>Editar</button>
                      <button onClick={(e) => { e.stopPropagation(); deleteWorkout(w.id); }} style={{ background: 'transparent', border: 'none', color: 'var(--danger)', fontSize: '11px', cursor: 'pointer' }}>Excluir</button>
                    </div>
                  )}
                </div>

                <div onClick={() => openWorkout(w)} style={{ padding: '16px', display: 'flex', alignItems: 'center', gap: '16px', cursor: 'pointer' }}>
                  <div style={{ width: '48px', height: '48px', borderRadius: '10px', overflow: 'hidden', flexShrink: 0, background: 'var(--panel-2)', display: 'grid', placeItems: 'center', color: 'var(--accent)' }}>
                    {w.cover_url ? (
                      <img src={w.cover_url} alt={w.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <IconDumbbell />
                    )}
                  </div>
                  <div style={{ flex: 1 }}>
                    <h4 style={{ margin: 0, fontSize: '15px' }}>{w.name}</h4>
                    <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'var(--muted)' }}>{w.description}</p>
                  </div>
                  <span style={{ color: 'var(--muted)' }}>→</span>
                </div>
              </div>
            )) : (
              <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--muted)' }}><IconDumbbell /><p>Nenhum treino disponível.</p></div>
            )}
          </section>
        )}

        {/* ABA: NOVA OCORRÊNCIA */}
        {currentTab === 'new-occurrence' && !isWorkoutActive && (
          <section style={{ maxWidth: '600px' }}>
             <button onClick={() => setCurrentTab('home')} style={{ background: 'transparent', border: 'none', color: 'var(--accent)', marginBottom: '20px', fontSize: '14px', padding: 0 }}>← Voltar</button>
             <h1>Nova <em style={{color: 'var(--accent)'}}>Ocorrência.</em></h1>
             <p style={{ color: 'var(--muted)', marginBottom: '30px' }}>Sua contribuição ajuda a manter o ambiente seguro para todos.</p>
             
             <form onSubmit={submitOccurrence} className="auth-form">
               <label style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                 Categoria do Problema
                 <select 
                   value={occurrenceCategory} 
                   onChange={e => setOccurrenceCategory(e.target.value)} 
                   style={{ height: '50px', borderRadius: '10px', padding: '0 14px', background: 'var(--field)', color: 'var(--text)', border: '1px solid var(--line)', outline: 'none', fontSize: '14px' }}
                 >
                   <option value="equipment">Equipamento Danificado</option>
                   <option value="injury">Acidente / Lesão</option>
                   <option value="accessibility">Barreira de Acessibilidade</option>
                   <option value="harassment">Assédio</option>
                   <option value="conduct">Conduta Inadequada</option>
                   <option value="other">Outro</option>
                 </select>
               </label>

               <label style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                 Local
                 <input 
                   type="text" 
                   value={occurrenceLocation} 
                   onChange={e=>setOccurrenceLocation(e.target.value)} 
                   placeholder="Ex: Peso livre, Esteira 3" 
                   required 
                   style={{ height: '50px', borderRadius: '10px', padding: '0 14px', background: 'var(--field)', color: 'var(--text)', border: '1px solid var(--line)', outline: 'none', fontSize: '14px' }}
                 />
               </label>

               <label style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                 Descrição
                 <textarea 
                   value={occurrenceDesc} 
                   onChange={e=>setOccurrenceDesc(e.target.value)} 
                   required 
                   placeholder="O que aconteceu? Seja o mais detalhado possível..." 
                   style={{ minHeight:'120px', padding: '14px', borderRadius: '10px', background: 'var(--field)', color: 'var(--text)', border: '1px solid var(--line)', fontFamily: 'inherit', resize: 'vertical', outline: 'none', fontSize: '14px' }}
                 />
               </label>

               {error && <div className="feedback feedback-error">{error}</div>}
               {message && <div className="feedback feedback-success">{message}</div>}
               
               <button className="submit-button" type="submit" disabled={busy} style={{ marginTop: '10px', height: '54px' }}>
                 Enviar Ocorrência
               </button>
             </form>
          </section>
        )}

        {/* ABA: DETALHES DO TREINO */}
        {currentTab === 'workout-details' && selectedWorkout && (
          <section style={{ paddingBottom: isWorkoutActive ? '100px' : '0' }}>
            
            {isWorkoutActive ? (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
                <button onClick={() => { if(window.confirm("Sair do treino atual? O progresso será perdido.")) setIsWorkoutActive(false); }} style={{ background: 'transparent', border: 'none', color: 'var(--text)', fontSize: '20px', cursor: 'pointer' }}>←</button>
                <span style={{ fontSize: '16px', fontWeight: 'bold', color: 'var(--accent)' }}>{formatTime(workoutTimer)}</span>
                <span style={{ fontSize: '20px', color: 'var(--muted)' }}>📶</span>
              </div>
            ) : (
              <button onClick={() => setCurrentTab('workouts')} style={{ background: 'transparent', border: 'none', color: 'var(--accent)', marginBottom: '20px', fontSize: '14px', padding: 0 }}>← Voltar para Treinos</button>
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px', marginBottom: '20px' }}>
              <div>
                <h1 style={{ fontSize: '32px', marginBottom: '5px' }}>{selectedWorkout.name}</h1>
                <p style={{ color: 'var(--muted)', margin: 0 }}>{selectedWorkout.description}</p>
              </div>
              
              {!isWorkoutActive && selectedWorkout.user_id === user.id && (
                <button onClick={openCatalog} className="submit-button" style={{ width: 'auto', padding: '0 15px', margin: 0 }}>
                  + Exercício
                </button>
              )}
            </div>

            {!isWorkoutActive && (
              <button onClick={() => { setIsWorkoutActive(true); setWorkoutTimer(0); setCompletedExercises([]); }} className="submit-button" style={{ width: '100%', marginBottom: '20px', height: '56px', fontSize: '16px' }}>
                INICIAR TREINO
              </button>
            )}

            {/* MODAL DE CATÁLOGO */}
            {isAddingExercise && (
              <div className="adaptation-overlay" style={{ zIndex: 3000 }}>
                <div className="adaptation-content">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                    <h3 style={{ margin: 0 }}>Adicionar Exercício</h3>
                    <button onClick={() => { setIsAddingExercise(false); setSelectedCatalogEx(null); }} style={{ background: 'transparent', border: 'none', color: 'var(--muted)', fontSize: '20px', cursor: 'pointer' }}>✕</button>
                  </div>

                  {!selectedCatalogEx ? (
                    <>
                      <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '15px', marginBottom: '15px', borderBottom: '1px solid var(--line)' }}>
                        {['Todos', 'Peito', 'Costas', 'Pernas', 'Ombros', 'Bíceps', 'Tríceps', 'Abdômen'].map(group => (
                          <button key={group} onClick={() => setFilterGroup(group)} style={{ padding: '6px 14px', borderRadius: '20px', border: '1px solid', background: filterGroup === group ? 'var(--accent)' : 'transparent', color: filterGroup === group ? 'var(--accent-ink)' : 'var(--text)', borderColor: filterGroup === group ? 'var(--accent)' : 'var(--line)', fontSize: '12px', fontWeight: 'bold', cursor: 'pointer', whiteSpace: 'nowrap' }}>{group}</button>
                        ))}
                      </div>
                      <div style={{ maxHeight: '50vh', overflowY: 'auto' }}>
                        {catalogList.filter(ex => filterGroup === 'Todos' || ex.muscle_group === filterGroup).map(ex => (
                          <div key={ex.id} className="exercise-item" onClick={() => setSelectedCatalogEx(ex)} style={{ padding: '10px' }}>
                            <div className="exercise-info">
                              <div className="exercise-thumb" style={{ width: '48px', height: '48px' }}>
                                {ex.media_url ? (
                                  <img src={ex.media_url} alt={ex.name} onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'block'; }} />
                                ) : null}
                                <div style={{ display: ex.media_url ? 'none' : 'block', width: '100%', height: '100%', placeItems: 'center', display: 'grid' }}>
                                  <IconDumbbell />
                                </div>
                              </div>
                              <div><h4 style={{ margin: 0, fontSize: '14px' }}>{ex.name}</h4><p style={{ margin: '2px 0 0', fontSize: '11px', color: 'var(--accent)' }}>{ex.muscle_group}</p></div>
                            </div>
                            <span style={{ color: 'var(--muted)' }}>+</span>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    <form onSubmit={confirmAddExercise} className="auth-form">
                      <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '15px' }}>
                        <div className="exercise-thumb" style={{ width: '64px', height: '64px' }}>
                          {selectedCatalogEx.media_url ? <img src={selectedCatalogEx.media_url} alt={selectedCatalogEx.name} onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'block'; }} /> : null}
                          <div style={{ display: selectedCatalogEx.media_url ? 'none' : 'block', width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}><IconDumbbell /></div>
                        </div>
                        <div><h4 style={{ margin: 0, fontSize: '18px' }}>{selectedCatalogEx.name}</h4><p style={{ margin: 0, fontSize: '12px', color: 'var(--accent)' }}>{selectedCatalogEx.muscle_group}</p></div>
                      </div>
                      <div style={{ display: 'flex', gap: '10px' }}>
                        <label style={{ flex: 1 }}>Séries<input type="number" value={newExSets} onChange={e => setNewExSets(e.target.value)} required /></label>
                        <label style={{ flex: 1 }}>Repetições<input value={newExReps} onChange={e => setNewExReps(e.target.value)} required /></label>
                        <label style={{ flex: 1 }}>Descanso (s)<input type="number" value={newExRest} onChange={e => setNewExRest(e.target.value)} required /></label>
                      </div>
                      <div style={{ display: 'flex', gap: '10px', marginTop: '15px' }}>
                        <button className="submit-button" type="submit" disabled={busy} style={{ flex: 1 }}>Adicionar</button>
                        <button type="button" onClick={() => setSelectedCatalogEx(null)} className="submit-button" style={{ flex: 1, background: 'transparent', border: '1px solid var(--line)', color: 'var(--text)' }}>Voltar</button>
                      </div>
                    </form>
                  )}
                </div>
              </div>
            )}

            <h3 style={{ marginTop: '20px' }}>{isWorkoutActive ? 'Exercícios do Treino' : 'Exercícios'}</h3>
            {exercises.length > 0 ? exercises.map(ex => {
              const isChecked = completedExercises.includes(ex.id);
              return (
                <div key={ex.id} className="exercise-item" style={{ background: isWorkoutActive ? 'var(--panel)' : 'var(--panel-2)', border: isChecked ? '1px solid var(--accent)' : '1px solid var(--line)', flexDirection: 'column', alignItems: 'stretch', padding: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', padding: '12px', cursor: 'pointer' }} onClick={() => !isWorkoutActive && openExercise(ex)}>
                    {isWorkoutActive && (
                      <div onClick={(e) => { e.stopPropagation(); toggleExerciseCheck(ex.id); }} style={{ width: '24px', height: '24px', borderRadius: '6px', border: isChecked ? 'none' : '2px solid var(--muted)', background: isChecked ? 'var(--accent)' : 'transparent', display: 'grid', placeItems: 'center', marginRight: '15px', cursor: 'pointer', color: 'var(--accent-ink)', fontWeight: 'bold' }}>
                        {isChecked && '✓'}
                      </div>
                    )}
                    <div className="exercise-info">
                      <div className="exercise-thumb">
                        {ex.media_url ? <img src={ex.media_url} alt={ex.name} style={{ opacity: isChecked ? 0.5 : 1 }} onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'block'; }} /> : null}
                        <div style={{ display: ex.media_url ? 'none' : 'block', width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}><IconDumbbell /></div>
                        <div className="thumb-badge">{ex.rest_time || 60}s</div>
                      </div>
                      <div>
                        <h4 style={{ margin: 0, fontSize: '15px', textDecoration: isChecked ? 'line-through' : 'none', color: isChecked ? 'var(--muted)' : 'var(--text)' }}>{ex.name}</h4>
                        <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'var(--muted)' }}>{ex.sets} séries • {ex.reps}</p>
                      </div>
                    </div>
                    {!isWorkoutActive && <span style={{ color: 'var(--muted)', marginLeft: 'auto' }}>›</span>}
                  </div>
                </div>
              );
            }) : <p style={{ color: 'var(--muted)' }}>Nenhum exercício cadastrado neste treino.</p>}

            {isWorkoutActive && (
              <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, padding: '15px', background: 'var(--bg)', borderTop: '1px solid var(--line)', zIndex: 100 }}>
                <button onClick={finishWorkout} disabled={busy} className="submit-button" style={{ width: '100%', height: '56px', fontSize: '16px', margin: 0 }}>
                  Finalizar treino
                </button>
              </div>
            )}
          </section>
        )}

        {/* ABA: DETALHES DO EXERCÍCIO */}
        {currentTab === 'workout-details' && selectedExercise && (
          <div className="adaptation-overlay" onClick={() => setSelectedExercise(null)}>
            <div className="adaptation-content" onClick={e => e.stopPropagation()}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h2 style={{ margin: 0, fontSize: '24px' }}>{selectedExercise.name}</h2>
                <button onClick={() => setSelectedExercise(null)} style={{ background: 'transparent', border: 'none', color: 'var(--muted)', fontSize: '20px', cursor: 'pointer' }}>✕</button>
              </div>
              <div style={{ background: 'var(--panel-2)', borderRadius: '12px', height: '220px', marginBottom: '20px', overflow: 'hidden', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                {selectedExercise.media_url ? <img src={selectedExercise.media_url} alt={selectedExercise.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ color: 'var(--muted)', fontSize: '13px' }}>Sem imagem</span>}
              </div>
              <div style={{ marginBottom: '20px' }}>
                <h4 style={{ margin: '0 0 5px' }}>Descrição</h4>
                <p style={{ fontSize: '13px', lineHeight: '1.6', color: 'var(--muted)', margin: 0 }}>Exercício para fortalecimento muscular, focado no movimento correto.</p>
              </div>
              {!showAdaptation ? (
                <button className="submit-button" onClick={() => setShowAdaptation(true)}>ADAPTAR EXERCÍCIO</button>
              ) : (
                <div>
                  <h3 style={{ fontSize: '16px', marginBottom: '15px', color: 'var(--accent)' }}>Selecione a necessidade:</h3>
                  {adaptations.length > 0 ? adaptations.map(ad => (
                    <div key={ad.id} style={{ marginBottom: '10px' }}>
                      <button className={`adaptation-btn ${expandedAdaptation === ad.id ? 'active' : ''}`} onClick={() => setExpandedAdaptation(expandedAdaptation === ad.id ? null : ad.id)}>
                        <span>{ad.disability_type === 'mobility' ? 'Mobilidade Reduzida' : ad.disability_type === 'visual' ? 'Deficiência Visual' : ad.disability_type === 'hearing' ? 'Deficiência Auditiva' : 'Deficiência Intelectual'}</span>
                        <span>{expandedAdaptation === ad.id ? '↑' : '→'}</span>
                      </button>
                      {expandedAdaptation === ad.id && <div className="adaptation-detail"><p style={{ margin: 0, fontSize: '13px', lineHeight: '1.6' }}>{ad.instructions}</p></div>}
                    </div>
                  )) : <p style={{ fontSize: '13px', color: 'var(--muted)' }}>Nenhuma adaptação específica.</p>}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ABA: PERFIL */}
        {currentTab === 'profile' && !isWorkoutActive && (
          <section style={{ maxWidth: '600px' }}>
            <h1>Meu <em style={{color: 'var(--accent)'}}>Perfil.</em></h1>
            <form onSubmit={saveStudentDetails} className="auth-form" style={{ marginTop: '20px' }}>
              <div style={{ display: 'flex', gap: '10px' }}>
                <label style={{ flex: 1 }}>Peso (kg)<input type="number" step="0.1" value={weight} onChange={e => setWeight(e.target.value)} /></label>
                <label style={{ flex: 1 }}>Altura (cm)<input type="number" value={height} onChange={e => setHeight(e.target.value)} /></label>
              </div>
              <div className="accessibility-section">
                <h3>Necessidades Específicas</h3>
                <div className="toggle-row"><span>Mobilidade Reduzida</span><label className="switch"><input type="checkbox" checked={hasMobility} onChange={e => setHasMobility(e.target.checked)} /><span className="slider"></span></label></div>
                <div className="toggle-row"><span>Deficiência Visual</span><label className="switch"><input type="checkbox" checked={hasVisual} onChange={e => setHasVisual(e.target.checked)} /><span className="slider"></span></label></div>
                <div className="toggle-row"><span>Deficiência Auditiva</span><label className="switch"><input type="checkbox" checked={hasHearing} onChange={e => setHasHearing(e.target.checked)} /><span className="slider"></span></label></div>
                <div className="toggle-row"><span>Deficiência Intelectual</span><label className="switch"><input type="checkbox" checked={hasIntellectual} onChange={e => setHasIntellectual(e.target.checked)} /><span className="slider"></span></label></div>
              </div>
              {message && <div className="feedback feedback-success">{message}</div>}
              <button className="submit-button" type="submit">Salvar</button>
            </form>
          </section>
        )}
      </main>

      {!isWorkoutActive && (
        <nav className="bottom-nav">
          <NavItems currentTab={currentTab} setCurrentTab={setCurrentTab} isStaff={isStaff} isSidebar={false} />
        </nav>
      )}
    </div>
  )
}

// ================= COMPONENTES AUXILIARES =================
function NavItems({ currentTab, setCurrentTab, isStaff, isSidebar }) {
  return (
    <>
      <button className={`nav-item ${currentTab === 'home' ? 'active' : ''}`} onClick={() => setCurrentTab('home')}><IconHome /> <span>Início</span></button>
      {!isStaff ? (
        <>
          <button className={`nav-item ${currentTab === 'workouts' || currentTab === 'workout-details' ? 'active' : ''}`} onClick={() => setCurrentTab('workouts')}><IconDumbbell /> <span>Treinos</span></button>
          <button className={`nav-item ${currentTab === 'schedule' ? 'active' : ''}`} onClick={() => setCurrentTab('schedule')}><IconCalendar /> <span>Agenda</span></button>
          <button className={`nav-item ${currentTab === 'profile' ? 'active' : ''}`} onClick={() => setCurrentTab('profile')}><IconUser /> <span>Perfil</span></button>
        </>
      ) : (
        <>
          <button className="nav-item"><IconChart /> <span>Relatórios</span></button>
          <button className="nav-item"><IconUsers /> <span>Equipe</span></button>
          <button className={`nav-item ${currentTab === 'profile' ? 'active' : ''}`} onClick={() => setCurrentTab('profile')}><IconUser /> <span>Perfil</span></button>
        </>
      )}
    </>
  )
}

function Brand() {
  return <div className="brand-lockup"><span className="brand-symbol"><span /><span /><span /></span><span className="brand-word">INCLUA<span className="brand-period">.</span></span></div>
}

function GoogleMark() {
  return <svg viewBox="0 0 48 48" aria-hidden="true" style={{width:'20px', height:'20px'}}><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.25 5.48-4.73 7.18l7.65 5.94c4.47-4.13 7.12-10.2 7.12-17.59Z"/><path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.52 2.56 10.78l7.97-6.19Z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.86l-7.65-5.94c-2.13 1.45-4.89 2.3-8.26 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48Z"/></svg>
}

function IconHome() { return <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg> }
function IconDumbbell() { return <svg viewBox="0 0 24 24" style={{width:'24px',height:'24px',color:'var(--muted)'}}><path d="M6.5 6.5h11M6.5 17.5h11M6 9v6M18 9v6"/><rect x="2" y="7" width="4" height="10" rx="1"/><rect x="18" y="7" width="4" height="10" rx="1"/></svg> }
function IconCalendar() { return <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg> }
function IconUser() { return <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> }
function IconShield() { return <svg viewBox="0 0 24 24" style={{width: '24px', height: '24px'}}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4" stroke="var(--accent)" strokeWidth="2"/></svg> }
function IconMap() { return <svg viewBox="0 0 24 24" style={{width: '40px', height: '40px', color: 'var(--accent)', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round'}}><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg> }
function IconChart() { return <svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg> }
function IconUsers() { return <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg> }