import { useEffect, useState } from 'react'
import { supabase } from './lib/supabaseClient'
import './App.css'

const BRAND = 'INCLUA'
const SPLASH_DURATION = 5000

function App() {
  const [stage, setStage] = useState('splash')
  const [user, setUser] = useState(null)
  const [theme, setTheme] = useState(() => localStorage.getItem('inclua-theme') || 'dark')
  const [mode, setMode] = useState('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('inclua-theme', theme)
  }, [theme])

  useEffect(() => {
    let alive = true
    const startedAt = Date.now()
    const reveal = (session) => {
      if (!alive) return
      setUser(session?.user ?? null)
      const recoveryFlow = window.location.hash.includes('type=recovery')
      if (recoveryFlow) setMode('update-password')
      const remaining = Math.max(0, SPLASH_DURATION - (Date.now() - startedAt))
      window.setTimeout(() => {
        if (alive) setStage(recoveryFlow ? 'auth' : session?.user ? 'home' : 'auth')
      }, remaining)
    }

    supabase.auth.getSession().then(({ data, error: sessionError }) => {
      if (sessionError) setError(sessionError.message)
      reveal(data?.session)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!alive) return
      setUser(session?.user ?? null)
      if (event === 'PASSWORD_RECOVERY') { setMode('update-password'); setStage('auth') }
      else if (session?.user) setStage('home')
      else if (stage !== 'splash') setStage('auth')
    })

    return () => {
      alive = false
      subscription.unsubscribe()
    }
    // The initial session check and auth listener are intentionally mounted once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function clearFeedback() {
    setError('')
    setMessage('')
  }

  async function signInGoogle() {
    clearFeedback()
    setBusy(true)
    const { error: authError } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    })
    if (authError) {
      setError(authError.message)
      setBusy(false)
    }
  }

  async function submitEmail(event) {
    event.preventDefault()
    clearFeedback()
    setBusy(true)

    if (mode === 'update-password') {
      if (password.length < 6) setError('A senha precisa ter pelo menos 6 caracteres.')
      else if (password !== confirmPassword) setError('As senhas não coincidem.')
      else {
        const { error: updateError } = await supabase.auth.updateUser({ password })
        if (updateError) setError(updateError.message)
        else {
          setMessage('Senha atualizada com sucesso! Você já pode continuar.')
          window.history.replaceState({}, document.title, window.location.pathname)
          setMode('login')
          setPassword('')
          setConfirmPassword('')
        }
      }
    } else if (mode === 'signup') {
      const { data, error: authError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: { full_name: name.trim() },
          emailRedirectTo: window.location.origin,
        },
      })
      if (authError) setError(authError.message)
      else if (data.session) {
        setUser(data.user)
        setStage('home')
      } else {
        setMessage('Cadastro criado! Confira seu e-mail para confirmar sua conta antes de entrar.')
        setMode('login')
      }
    } else {
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      })
      if (authError) setError(authError.message)
      else {
        setUser(data.user)
        setStage('home')
      }
    }
    setBusy(false)
  }

  async function recoverPassword() {
    clearFeedback()
    if (!email.trim()) {
      setError('Digite seu e-mail no campo acima para receber o link de recuperação.')
      return
    }
    setBusy(true)
    const { error: authError } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: window.location.origin,
    })
    if (authError) setError(authError.message)
    else setMessage('Se esse e-mail estiver cadastrado, você receberá as instruções de recuperação.')
    setBusy(false)
  }

  async function signOut() {
    setBusy(true)
    const { error: authError } = await supabase.auth.signOut()
    if (authError) setError(authError.message)
    else {
      setUser(null)
      setStage('auth')
      setMode('login')
      clearFeedback()
    }
    setBusy(false)
  }

  const firstName = user?.user_metadata?.full_name?.split(' ')[0]
    || user?.user_metadata?.name?.split(' ')[0]
    || user?.email?.split('@')[0]
    || 'por aqui'

  if (stage === 'splash') {
    return (
      <main className="splash-screen" aria-label="Carregando INCLUA">
        <div className="splash-orbit orbit-one" />
        <div className="splash-orbit orbit-two" />
        <div className="brand-lockup splash-lockup">
          <span className="brand-symbol"><span /><span /><span /></span>
          <span className="brand-word">INCLUA<span className="brand-period">.</span></span>
        </div>
        <p className="splash-tagline">MOVIMENTO É PARA TODO MUNDO.</p>
        <div className="splash-bottom">
          <span className="loading-line"><i /></span>
          <span>PREPARANDO UM NOVO JEITO DE TREINAR</span>
        </div>
      </main>
    )
  }

  if (stage === 'auth') {
    return (
      <main className="auth-layout">
        <section className="auth-showcase">
          <div className="showcase-glow" />
          <header className="showcase-header">
            <Brand />
            <span className="showcase-pill"><i /> SEGURANÇA • ACESSIBILIDADE • INCLUSÃO</span>
          </header>
          <div className="showcase-copy">
            <p className="eyebrow">UM NOVO ESPAÇO PARA TODOS</p>
            <h1>Seu movimento.<br /><em>Seu espaço.</em><br />Seu jeito.</h1>
            <p className="showcase-description">Conectamos pessoas a ambientes fitness mais seguros, acessíveis e preparados para acolher todas as formas de movimento.</p>
            <div className="showcase-values">
              <div><span className="value-icon">↗</span><span><b>Mais autonomia</b><small>Escolhas com informação</small></span></div>
              <div><span className="value-icon">⌁</span><span><b>Mais segurança</b><small>Ambientes acompanhados</small></span></div>
              <div><span className="value-icon">◎</span><span><b>Mais inclusão</b><small>Espaço para cada pessoa</small></span></div>
            </div>
          </div>
          <div className="showcase-footer"><span>INCLUA / 001</span><span>ACESSO, RESPEITO E MOVIMENTO.</span></div>
        </section>

        <section className="auth-panel">
          <div className="auth-panel-top">
            <span className="mobile-brand"><Brand /></span>
            <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Alternar tema">
              <span>{theme === 'dark' ? '☼' : '☾'}</span>{theme === 'dark' ? 'Modo claro' : 'Modo escuro'}
            </button>
          </div>
          <div className="auth-card">
            <div className="auth-heading">
              <span className="eyebrow">BEM-VINDO À INCLUA</span>
              <h2>{mode === 'signup' ? 'Crie sua conta.' : mode === 'update-password' ? 'Nova senha.' : 'Que bom ter você.'}</h2>
              <p>{mode === 'signup' ? 'Seu próximo passo começa com um cadastro.' : mode === 'update-password' ? 'Escolha uma nova senha para proteger sua conta.' : 'Entre para descobrir um universo fitness mais inclusivo.'}</p>
            </div>

            {mode !== 'update-password' && <button className="google-signin" onClick={signInGoogle} disabled={busy}>
              <GoogleMark /> <span>Continuar com Google</span>
            </button>}

            {mode !== 'update-password' && <div className="auth-divider"><span />OU CONTINUE COM E-MAIL<span /></div>}

            <form className="auth-form" onSubmit={submitEmail}>
              {mode === 'signup' && (
                <label>Nome completo
                  <input autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Como podemos te chamar?" required />
                </label>
              )}
              {mode !== 'update-password' && <label>E-mail
                <input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" required />
              </label>}
              <label>{mode === 'update-password' ? 'Nova senha' : 'Senha'}
                <input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mínimo de 6 caracteres" minLength={6} required />
              </label>
              {mode === 'update-password' && <label>Confirme a nova senha
                <input type="password" autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Digite a senha novamente" minLength={6} required />
              </label>}
              {mode === 'login' && <button type="button" className="forgot-link" onClick={recoverPassword}>Esqueceu sua senha?</button>}
              <button className="submit-button" type="submit" disabled={busy}>
                {busy ? <span className="button-spinner" /> : null}
                {busy ? 'Aguarde...' : mode === 'signup' ? 'Criar minha conta' : mode === 'update-password' ? 'Salvar nova senha' : 'Entrar na INCLUA'}
                {!busy && <span>→</span>}
              </button>
            </form>

            {error && <div className="feedback feedback-error" role="alert">{error}</div>}
            {message && <div className="feedback feedback-success" role="status">{message}</div>}

            {mode !== 'update-password' && <p className="switch-auth">
              {mode === 'signup' ? 'Já tem uma conta?' : 'Ainda não tem uma conta?'}
              <button onClick={() => { clearFeedback(); setMode(mode === 'signup' ? 'login' : 'signup') }}>
                {mode === 'signup' ? 'Fazer login' : 'Criar conta'}
              </button>
            </p>}
            <p className="terms">Ao continuar, você concorda com nossos termos de uso e política de privacidade.</p>
          </div>
          <footer className="auth-footer"><span>© 2026 INCLUA</span><span>FEITO PARA TODOS. SEM EXCEÇÃO.</span></footer>
        </section>
      </main>
    )
  }

  return (
    <main className="welcome-layout">
      <header className="welcome-header">
        <Brand />
        <div className="welcome-actions">
          <button className="theme-toggle" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Alternar tema">
            <span>{theme === 'dark' ? '☼' : '☾'}</span>{theme === 'dark' ? 'Modo claro' : 'Modo escuro'}
          </button>
          <button className="profile-chip" onClick={signOut}>
            {user?.user_metadata?.avatar_url
              ? <img src={user.user_metadata.avatar_url} alt="" referrerPolicy="no-referrer" />
              : <span className="profile-initial">{firstName.charAt(0).toUpperCase()}</span>}
            <span>{firstName}</span><small>{busy ? 'Saindo...' : 'Sair ↗'}</small>
          </button>
        </div>
      </header>
      <section className="welcome-content">
        <div className="welcome-kicker"><i /> CONTA CONECTADA COM SUCESSO</div>
        <h1>Bem-vindo(a),<br /><em>{firstName}.</em></h1>
        <p className="welcome-lead">Seu espaço para encontrar academias mais seguras, acessíveis e inclusivas começa aqui.</p>
        <div className="welcome-feature-grid">
          <article className="welcome-feature feature-primary">
            <span className="feature-number">01 / EXPLORAR</span>
            <span className="feature-art">◎</span>
            <h2>Encontre seu<br />lugar de movimento.</h2>
            <p>Descubra academias e conheça seus recursos de acessibilidade.</p>
            <span className="feature-soon">PRÓXIMA ETAPA <b>↗</b></span>
          </article>
          <article className="welcome-feature">
            <span className="feature-number">02 / SEGURANÇA</span>
            <span className="feature-art">⌁</span>
            <h2>Treinar com<br />mais tranquilidade.</h2>
            <p>Um canal para comunicar riscos, incidentes e equipamentos.</p>
            <span className="feature-soon">PRÓXIMA ETAPA <b>↗</b></span>
          </article>
          <article className="welcome-feature">
            <span className="feature-number">03 / INCLUSÃO</span>
            <span className="feature-art">✳</span>
            <h2>Um espaço que<br />acolhe diferenças.</h2>
            <p>Informações para apoiar escolhas com autonomia e respeito.</p>
            <span className="feature-soon">PRÓXIMA ETAPA <b>↗</b></span>
          </article>
        </div>
        <div className="welcome-note"><span>✳</span><p><b>Estamos construindo isso juntos.</b> Esta é a primeira etapa da INCLUA. As próximas entregas vão ativar os módulos de academias, segurança, acessibilidade e gestão.</p></div>
      </section>
      <footer className="welcome-footer"><span>INCLUA / MOVIMENTO É PARA TODO MUNDO.</span><span>VERSÃO 0.1 — FUNDAÇÃO</span></footer>
    </main>
  )
}

function Brand() {
  return <div className="brand-lockup"><span className="brand-symbol"><span /><span /><span /></span><span className="brand-word">INCLUA<span className="brand-period">.</span></span></div>
}

function GoogleMark() {
  return <svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.25 5.48-4.73 7.18l7.65 5.94c4.47-4.13 7.12-10.2 7.12-17.59Z"/><path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.52 2.56 10.78l7.97-6.19Z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.86l-7.65-5.94c-2.13 1.45-4.89 2.3-8.26 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48Z"/></svg>
}

export default App
