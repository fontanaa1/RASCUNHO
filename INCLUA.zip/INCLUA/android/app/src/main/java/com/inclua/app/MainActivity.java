
package com.inclua.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
