// ===================== MENU MOBILE =====================
const overlay = document.getElementById("mobileMenuOverlay");
const icon = document.getElementById("menuIcon");
const bottomNav = document.querySelector(".bottom-nav");

function toggleMobileMenu() {
    overlay.classList.toggle("active");

    // Muda o ícone
    icon.textContent = overlay.classList.contains("active") ? "close" : "menu";

    // Bloqueia/desbloqueia rolagem
    document.body.style.overflow = overlay.classList.contains("active") ? "hidden" : "";

    // Esconde/mostra bottom nav
    if (bottomNav) {
        bottomNav.style.display = overlay.classList.contains("active") ? "none" : "flex";
    }
}

function closeMobileMenu() {
    overlay.classList.remove("active");
    icon.textContent = "menu";
    document.body.style.overflow = "";
    if (bottomNav) {
        bottomNav.style.display = "flex";
    }
}

function navigateTo(page) {
    if (router) {
        router.render(page);
        router.updateActiveNav(page);
    }
    closeMobileMenu();
}

// Fechar clicando fora (no overlay)
overlay.addEventListener("click", function (e) {
    if (e.target === overlay) {
        closeMobileMenu();
    }
});

// Fechar ao pressionar ESC
document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
        closeMobileMenu();
    }
});

// Fechar ao clicar em qualquer menu-item
document.querySelectorAll(".menu-item").forEach(function (item) {
    item.addEventListener("click", function () {
        closeMobileMenu();
    });
});

// ===================== DATA =====================
const DATA = {
    exercises: [
        { id: 1, name: 'Supino Reto', group: 'Peito', description: 'Exercício básico para peito', muscles: ['Peitoral', 'Tríceps', 'Deltoide'], equipment: 'Barra', difficulty: 'Intermediário', sets: 4, reps: '8-12', rest: 60, image: 'https://www.mundoboaforma.com.br/wp-content/uploads/2020/12/supino-reto.gif' },
        { id: 2, name: 'Puxada Frontal', group: 'Costas', description: 'Exercício para costas', muscles: ['Latíssimo', 'Bíceps', 'Trapézio'], equipment: 'Polia', difficulty: 'Intermediário', sets: 4, reps: '10-12', rest: 60, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPaCdstyCL7g313mGJwGkP1Et1-LCudzYuP_lK1XbTApi0iHPaX2oYnhs&s=10' },
        { id: 3, name: 'Leg Press', group: 'Pernas', description: 'Exercício para pernas', muscles: ['Quadríceps', 'Glúteos', 'Posterior'], equipment: 'Leg Press', difficulty: 'Iniciante', sets: 4, reps: '12-15', rest: 45, image: 'https://image.tuasaude.com/media/article/nb/le/leg-press_75589.gif?width=686&height=487' },
        { id: 4, name: 'Desenvolvimento', group: 'Ombro', description: 'Exercício para ombros', muscles: ['Deltoide', 'Tríceps', 'Trapézio'], equipment: 'Barra', difficulty: 'Intermediário', sets: 4, reps: '8-12', rest: 60, image: 'https://www.mundoboaforma.com.br/wp-content/uploads/2020/12/desenvolvimento-para-ombros-com-halteres.gif' },
        { id: 5, name: 'Rosca Scott', group: 'Bíceps', description: 'Exercício para bíceps', muscles: ['Bíceps', 'Braquial'], equipment: 'Banco Scott', difficulty: 'Iniciante', sets: 3, reps: '10-12', rest: 45, image: 'https://www.mundoboaforma.com.br/wp-content/uploads/2020/11/Rosca-Scott-com-halteres-com-dois-bracos.gif' },
        { id: 6, name: 'Tríceps Pulley', group: 'Tríceps', description: 'Exercício para tríceps', muscles: ['Tríceps'], equipment: 'Polia', difficulty: 'Iniciante', sets: 3, reps: '12-15', rest: 45, image: 'https://treinoemalta.com.br/wp-content/uploads/2023/07/Triceps-Pulley-Barra.gif' },
        { id: 7, name: 'Cadeira Extensora', group: 'Pernas', description: 'Exercício para quadríceps', muscles: ['Quadríceps'], equipment: 'Cadeira Extensora', difficulty: 'Iniciante', sets: 4, reps: '12-15', rest: 45, image: 'https://image.tuasaude.com/media/article/ov/fb/cadeira-extensora_75064.gif?width=686&height=487' },
        { id: 8, name: 'Mesa Flexora', group: 'Pernas', description: 'Exercício para posterior', muscles: ['Posterior'], equipment: 'Mesa Flexora', difficulty: 'Iniciante', sets: 4, reps: '12-15', rest: 45, image: 'https://i.pinimg.com/originals/4d/58/19/4d581995094c4cff1343dfe609118219.gif' },
        { id: 9, name: 'Peck Deck', group: 'Peito', description: 'Exercício para peito', muscles: ['Peitoral'], equipment: 'Peck Deck', difficulty: 'Intermediário', sets: 3, reps: '10-12', rest: 45, image: 'https://i.pinimg.com/originals/6d/99/ed/6d99ed8341629f7fc40eb361725d65dd.gif' },
        { id: 10, name: 'Remada Baixa', group: 'Costas', description: 'Exercício para costas', muscles: ['Latíssimo', 'Trapézio', 'Bíceps'], equipment: 'Polia', difficulty: 'Intermediário', sets: 4, reps: '10-12', rest: 60, image: 'https://media.tenor.com/vy_b35185M0AAAAM/remada-baixa-triangulo.gif' },
        { id: 11, name: 'Abdominal', group: 'Abdômen', description: 'Exercício para abdômen', muscles: ['Reto Abdominal'], equipment: 'Colchonete', difficulty: 'Iniciante', sets: 3, reps: '15-20', rest: 30, image: 'https://www.mundoboaforma.com.br/wp-content/uploads/2021/03/abdominal.gif' },
        { id: 12, name: 'Cardio', group: 'Cardio', description: 'Exercício cardiovascular', muscles: ['Sistema Cardiovascular'], equipment: 'Esteira', difficulty: 'Iniciante', sets: 1, reps: '20-30 min', rest: 0, image: 'https://www.hipertrofia.org/blog/wp-content/uploads/2024/09/walking-on-stepmill.gif' },
        { id: 13, name: 'Remada Máquina', group: 'Costas', description: 'Remada na máquina', muscles: ['Latíssimo', 'Trapézio'], equipment: 'Máquina', difficulty: 'Intermediário', sets: 3, reps: '12', rest: 60, image: 'https://static.wixstatic.com/media/2edbed_eb1a2f5a37ab496d8cc1297ed3b023a1~mv2.gif' },
        { id: 14, name: 'Puxada Polia Barra', group: 'Costas', description: 'Puxada na polia', muscles: ['Latíssimo', 'Bíceps'], equipment: 'Polia', difficulty: 'Intermediário', sets: 3, reps: '12', rest: 60, image: 'https://www.mundoboaforma.com.br/wp-content/uploads/2021/07/triceps-puxada-no-pulley.gif' },
        { id: 15, name: 'Supino Máquina', group: 'Peito', description: 'Supino na máquina', muscles: ['Peitoral', 'Tríceps'], equipment: 'Máquina', difficulty: 'Intermediário', sets: 3, reps: '12', rest: 60, image: 'https://www.hipertrofia.org/blog/wp-content/uploads/2024/04/lever-chest-press-.gif' },
    ],
    equipments: [
        { id: 1, name: 'Leg Press 45°', group: 'Pernas', difficulty: 'Intermediário', muscles: ['Quadríceps', 'Glúteos', 'Posterior'], sets: 4, reps: '10-12', rest: 60, load: '50-100kg', tips: 'Mantenha a coluna apoiada', errors: 'Tirar os glúteos do banco', posture: 'Pés na largura dos ombros', benefits: 'Fortalece pernas' },
        { id: 2, name: 'Supino Reto', group: 'Peito', difficulty: 'Intermediário', muscles: ['Peitoral', 'Tríceps', 'Deltoide'], sets: 4, reps: '8-10', rest: 60, load: '20-80kg', tips: 'Mantenha os pés no chão', errors: 'Arquear muito as costas', posture: 'Omoplatas no banco', benefits: 'Fortalece peito' },
        { id: 3, name: 'Cadeira Extensora', group: 'Pernas', difficulty: 'Iniciante', muscles: ['Quadríceps'], sets: 4, reps: '12-15', rest: 45, load: '20-60kg', tips: 'Controle o movimento', errors: 'Impulsionar com o corpo', posture: 'Joelhos alinhados', benefits: 'Fortalece quadríceps' },
        { id: 4, name: 'Mesa Flexora', group: 'Pernas', difficulty: 'Iniciante', muscles: ['Posterior'], sets: 4, reps: '12-15', rest: 45, load: '15-50kg', tips: 'Movimento controlado', errors: 'Levantar os quadris', posture: 'Mantenha o corpo reto', benefits: 'Fortalece posterior' },
        { id: 5, name: 'Puxada Frontal', group: 'Costas', difficulty: 'Intermediário', muscles: ['Latíssimo', 'Bíceps', 'Trapézio'], sets: 4, reps: '10-12', rest: 60, load: '20-70kg', tips: 'Puxe até o peito', errors: 'Puxar com os braços', posture: 'Costas retas', benefits: 'Fortalece costas' },
        { id: 6, name: 'Remada Baixa', group: 'Costas', difficulty: 'Intermediário', muscles: ['Latíssimo', 'Trapézio', 'Bíceps'], sets: 4, reps: '10-12', rest: 60, load: '20-60kg', tips: 'Puxe até o abdomen', errors: 'Usar força dos braços', posture: 'Costas retas', benefits: 'Fortalece costas' },
        { id: 7, name: 'Desenvolvimento', group: 'Ombro', difficulty: 'Intermediário', muscles: ['Deltoide', 'Tríceps', 'Trapézio'], sets: 4, reps: '8-12', rest: 60, load: '15-50kg', tips: 'Mantenha os cotovelos', errors: 'Arquear as costas', posture: 'Pés na largura', benefits: 'Fortalece ombros' },
        { id: 8, name: 'Peck Deck', group: 'Peito', difficulty: 'Intermediário', muscles: ['Peitoral'], sets: 3, reps: '10-12', rest: 45, load: '10-40kg', tips: 'Controle o movimento', errors: 'Usar força dos braços', posture: 'Costas apoiadas', benefits: 'Fortalece peitoral' },
        { id: 9, name: 'Hack Machine', group: 'Pernas', difficulty: 'Intermediário', muscles: ['Quadríceps', 'Glúteos'], sets: 4, reps: '10-12', rest: 60, load: '30-100kg', tips: 'Mantenha a coluna reta', errors: 'Tirar os glúteos', posture: 'Pés na plataforma', benefits: 'Fortalece pernas' },
        { id: 10, name: 'Smith Machine', group: 'Pernas', difficulty: 'Intermediário', muscles: ['Quadríceps', 'Glúteos', 'Peitoral'], sets: 4, reps: '8-12', rest: 60, load: '20-80kg', tips: 'Mantenha o movimento', errors: 'Desalinhar os joelhos', posture: 'Pés posicionados', benefits: 'Fortalece corpo' },
        { id: 11, name: 'Panturrilha', group: 'Pernas', difficulty: 'Iniciante', muscles: ['Panturrilha'], sets: 4, reps: '15-20', rest: 30, load: '20-60kg', tips: 'Movimento completo', errors: 'Usar impulso', posture: 'Mantenha o corpo ereto', benefits: 'Fortalece panturrilha' },
        { id: 12, name: 'Abdutora', group: 'Pernas', difficulty: 'Iniciante', muscles: ['Abdutores'], sets: 3, reps: '12-15', rest: 45, load: '10-40kg', tips: 'Controle o movimento', errors: 'Impulsionar', posture: 'Mantenha o corpo reto', benefits: 'Fortalece glúteos' },
        { id: 13, name: 'Adutora', group: 'Pernas', difficulty: 'Iniciante', muscles: ['Adutores'], sets: 3, reps: '12-15', rest: 45, load: '10-40kg', tips: 'Controle o movimento', errors: 'Impulsionar', posture: 'Mantenha o corpo reto', benefits: 'Fortalece coxas' },
        { id: 14, name: 'Rosca Scott', group: 'Bíceps', difficulty: 'Iniciante', muscles: ['Bíceps', 'Braquial'], sets: 3, reps: '10-12', rest: 45, load: '10-30kg', tips: 'Movimento controlado', errors: 'Usar força do ombro', posture: 'Braços apoiados', benefits: 'Fortalece bíceps' },
        { id: 15, name: 'Tríceps Pulley', group: 'Tríceps', difficulty: 'Iniciante', muscles: ['Tríceps'], sets: 3, reps: '12-15', rest: 45, load: '10-30kg', tips: 'Cotovelos fixos', errors: 'Mexer os cotovelos', posture: 'Corpo reto', benefits: 'Fortalece tríceps' },
    ],
    workouts: [
        {
            id: 1,
            name: 'Treino A',
            group: 'Peito, Ombro, Tríceps',
            exercises: [
                { name: 'Supino Reto', variation: 'Inclinado', sets: 4, reps: '10-12', rest: 60 },
                { name: 'Peck Deck', variation: 'Máquina', sets: 3, reps: '12-15', rest: 45 },
                { name: 'Desenvolvimento', variation: 'Máquina', sets: 4, reps: '10-12', rest: 60 },
                { name: 'Tríceps Pulley', variation: 'Polia', sets: 3, reps: '12-15', rest: 45 },
            ],
            time: '45min',
            difficulty: 'Intermediário',
            observations: 'Foque na execução',
            image: 'https://pratiquefitness.com.br/blog/wp-content/uploads/2023/07/Quais-sao-os-detalhes-que-fazem-a-diferenca-no-treino-na-academia-2.jpg'
        },
        {
            id: 2,
            name: 'Treino B',
            group: 'Dorsal, Peitoral, Ombro, Tríceps, Bíceps',
            exercises: [
                { name: 'Remada Máquina', variation: 'Neutra', sets: 3, reps: '12', rest: 60 },
                { name: 'Puxada Polia Barra', variation: 'Frente', sets: 3, reps: '12', rest: 60 },
                { name: 'Supino Máquina', variation: 'Inclinado', sets: 3, reps: '12', rest: 60 },
            ],
            time: '35min',
            difficulty: 'Intermediário',
            observations: 'Mantenha a postura',
            image: 'https://ciaathleticasjc.com.br/wp-content/uploads/2024/03/Cia-Athletica-SJC-Divisao-de-treino-ABC-Autores-Grupo-S2-Marketing-Freepik.jpg'
        },
        {
            id: 3,
            name: 'Treino de Pernas',
            group: 'Quadríceps, Posterior, Glúteos',
            exercises: [
                { name: 'Leg Press', variation: '45°', sets: 4, reps: '12-15', rest: 45 },
                { name: 'Cadeira Extensora', variation: 'Máquina', sets: 4, reps: '12-15', rest: 45 },
                { name: 'Mesa Flexora', variation: 'Deitado', sets: 4, reps: '12-15', rest: 45 },
                { name: 'Panturrilha', variation: 'Em pé', sets: 4, reps: '15-20', rest: 30 },
            ],
            time: '60min',
            difficulty: 'Intermediário',
            observations: 'Não trave os joelhos',
            image: 'https://boaforma.abril.com.br/wp-content/uploads/sites/2/2024/01/levantamento-terra.jpg?quality=70&strip=info&resize=1080,565&crop=1'
        },
        {
            id: 4,
            name: 'Treino de Costas',
            group: 'Latíssimo, Trapézio, Bíceps',
            exercises: [
                { name: 'Puxada Frontal', variation: 'Polia', sets: 4, reps: '10-12', rest: 60 },
                { name: 'Remada Baixa', variation: 'Triângulo', sets: 4, reps: '10-12', rest: 60 },
                { name: 'Rosca Scott', variation: 'Máquina', sets: 3, reps: '10-12', rest: 45 },
            ],
            time: '50min',
            difficulty: 'Intermediário',
            observations: 'Mantenha a postura',
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOCb8YBXsYvItrp3QeGtUxefD5wsm6y8dj_b1q6uUWUT5FKXoBO8lAN8RX&s=10'
        },
        {
            id: 5,
            name: 'Treino de Ombro',
            group: 'Deltoide, Trapézio',
            exercises: [
                { name: 'Desenvolvimento', variation: 'Barra', sets: 4, reps: '8-12', rest: 60 },
                { name: 'Elevação Lateral', variation: 'Halteres', sets: 3, reps: '12-15', rest: 45 },
                { name: 'Elevação Frontal', variation: 'Halteres', sets: 3, reps: '12-15', rest: 45 },
            ],
            time: '40min',
            difficulty: 'Intermediário',
            observations: 'Use carga moderada',
            image: 'https://irp.cdn-website.com/cbc52636/dms3rep/multi/treino-ombro-dr-guilherme-noffs-ortopedista-ombro-sao-paulo.jpg'
        },
        {
            id: 6,
            name: 'Treino de Bíceps e Tríceps',
            group: 'Bíceps, Tríceps',
            exercises: [
                { name: 'Rosca Scott', variation: 'Máquina', sets: 3, reps: '10-12', rest: 45 },
                { name: 'Rosca Alternada', variation: 'Halteres', sets: 3, reps: '10-12', rest: 45 },
                { name: 'Tríceps Pulley', variation: 'Polia', sets: 3, reps: '12-15', rest: 45 },
                { name: 'Tríceps Testa', variation: 'Barra', sets: 3, reps: '10-12', rest: 45 },
            ],
            time: '35min',
            difficulty: 'Iniciante',
            observations: 'Controle o movimento',
            image: 'https://v4excellencefitness.com.br/wp-content/uploads/2023/05/como-treinar-biceps.jpg'
        },
        {
            id: 7,
            name: 'Treino de Abdômen',
            group: 'Abdômen',
            exercises: [
                { name: 'Abdominal', variation: 'Supino', sets: 3, reps: '15-20', rest: 30 },
                { name: 'Prancha', variation: 'Isométrica', sets: 3, reps: '30s', rest: 30 },
                { name: 'Elevação de Pernas', variation: 'Suspenso', sets: 3, reps: '12-15', rest: 30 },
            ],
            time: '30min',
            difficulty: 'Iniciante',
            observations: 'Foco na contração',
            image: 'https://blog.ciaathletica.com.br/wp-content/uploads/2024/12/Cia-Athletica-Abdominal-infra-exercicio-pernas-elevadas-aparelho-mulher-academia-Autores-GS2-Marketing-Freepik.jpg'
        },
        {
            id: 8,
            name: 'Treino Cardio',
            group: 'Cardio',
            exercises: [
                { name: 'Corrida', variation: 'Esteira', sets: 1, reps: '20-30 min', rest: 0 },
                { name: 'Bicicleta', variation: 'Ergométrica', sets: 1, reps: '20-30 min', rest: 0 },
            ],
            time: '30min',
            difficulty: 'Iniciante',
            observations: 'Mantenha o ritmo',
            image: 'https://blog.prosportrs.com.br/wp-content/uploads/2024/08/Turbinando-sua-resist%C3%AAncia-o-trio-din%C3%A2mico-de-cardio-na-academia.jpg'
        },
    ]
};

// ===================== STORE =====================
const Store = {
    get(key, defaultVal = null) {
        try {
            const data = localStorage.getItem(`apex_${key}`);
            return data ? JSON.parse(data) : defaultVal;
        } catch { return defaultVal; }
    },
    set(key, val) {
        localStorage.setItem(`apex_${key}`, JSON.stringify(val));
    },
    getProfile() {
        return this.get('profile', { name: '', age: '', gender: '', height: '', weight: '', goal: '', level: '' });
    },
    setProfile(data) {
        this.set('profile', data);
    },
    getHistory() {
        return this.get('history', []);
    },
    addHistory(entry) {
        const history = this.getHistory();
        history.push({ ...entry, date: new Date().toISOString() });
        this.set('history', history);
    },
    getFavorites() {
        return this.get('favorites', { exercises: [], workouts: [] });
    },
    toggleFavorite(type, id) {
        const favs = this.getFavorites();
        const list = favs[type];
        const idx = list.indexOf(id);
        if (idx > -1) list.splice(idx, 1);
        else list.push(id);
        this.set('favorites', favs);
        return favs;
    },
    isFavorite(type, id) {
        const favs = this.getFavorites();
        return favs[type].includes(id);
    },
    getCompleted() {
        return this.get('completed', []);
    },
    toggleCompleted(exerciseId) {
        const completed = this.getCompleted();
        const idx = completed.indexOf(exerciseId);
        if (idx > -1) completed.splice(idx, 1);
        else completed.push(exerciseId);
        this.set('completed', completed);
        return completed;
    },
    getStats() {
        const history = this.getHistory();
        const completed = this.getCompleted();
        const totalWorkouts = history.length;
        const totalExercises = completed.length;
        const days = new Set(history.map(h => new Date(h.date).toDateString())).size;
        const streak = this.calculateStreak(history);
        const totalTime = history.reduce((acc, h) => acc + (h.time || 0), 0);
        return { totalWorkouts, totalExercises, days, streak, totalTime };
    },
    calculateStreak(history) {
        if (!history.length) return 0;
        const dates = history.map(h => new Date(h.date).toDateString());
        const uniqueDates = [...new Set(dates)];
        uniqueDates.sort((a, b) => new Date(b) - new Date(a));
        let streak = 0;
        let current = new Date();
        current.setHours(0, 0, 0, 0);
        for (let i = 0; i < uniqueDates.length; i++) {
            const date = new Date(uniqueDates[i]);
            date.setHours(0, 0, 0, 0);
            const diff = (current - date) / (1000 * 60 * 60 * 24);
            if (diff === streak) {
                streak++;
            } else if (diff > streak) {
                break;
            }
        }
        return streak;
    },
    clearAll() {
        localStorage.clear();
    },
    exportData() {
        const data = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('apex_')) {
                data[key] = localStorage.getItem(key);
            }
        }
        return data;
    },
    importData(data) {
        Object.keys(data).forEach(key => {
            localStorage.setItem(key, data[key]);
        });
    }
};

// ===================== ROUTER =====================
class Router {
    constructor() {
        this.currentPage = 'home';
        this.container = document.getElementById('contentArea');
        this.currentWorkoutId = null;
        this.bindNavigation();
        this.render('home');
        this.updateMenuUserName();
    }

    bindNavigation() {
        document.querySelectorAll('[data-page]').forEach(el => {
            el.addEventListener('click', (e) => {
                e.preventDefault();
                const page = el.dataset.page;
                this.render(page);
                this.updateActiveNav(page);
                closeMobileMenu();
            });
        });
    }

    updateActiveNav(page) {
        document.querySelectorAll('[data-page]').forEach(el => {
            el.classList.remove('active', 'bg-secondary-container', 'text-on-secondary-container');
            if (el.dataset.page === page) {
                el.classList.add('active');
                if (el.classList.contains('sidebar-item')) {
                    el.classList.add('bg-secondary-container', 'text-on-secondary-container');
                }
            }
        });
        // Atualizar menu mobile
        document.querySelectorAll('.menu-item').forEach(el => {
            el.classList.remove('active');
            if (el.dataset.page === page) {
                el.classList.add('active');
            }
        });
    }

    updateMenuUserName() {
        const profile = Store.getProfile();
        const userNameElement = document.getElementById('menuUserName');
        if (userNameElement && profile.name) {
            userNameElement.textContent = profile.name;
        }
    }

    render(page, params = null) {
        this.currentPage = page;
        const container = this.container;
        container.classList.add('animate-slide-up');

        switch (page) {
            case 'home': this.renderHome(container); break;
            case 'treinos': this.renderTreinos(container, params); break;
            case 'exercicios': this.renderExercicios(container); break;
            case 'progresso': this.renderProgresso(container); break;
            case 'scanner': this.renderScanner(container); break;
            case 'perfil': this.renderPerfil(container); break;
            case 'configuracoes': this.renderConfiguracoes(container); break;
            default: container.innerHTML = '<h1 class="text-2xl">Página não encontrada</h1>';
        }
    }

    renderHome(container) {
        const profile = Store.getProfile();
        const stats = Store.getStats();
        const nextExercise = this.getNextExercise();

        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <section>
                    <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface" id="greeting-text">
                        Olá, ${profile.name || 'Athlete'} 👋
                    </h2>
                    <p class="font-body-lg text-body-lg text-on-surface-variant mt-1">Pronto para alcançar seus objetivos hoje?</p>
                </section>

                <section class="relative rounded-xl overflow-hidden min-h-[200px] md:min-h-[280px] flex items-end p-lg group border border-outline-variant/20">
                    <div class="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" 
                         style="background-image: url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 800 400%22%3E%3Crect fill=%22%2311131b%22 width=%22800%22 height=%22400%22/%3E%3Ccircle cx=%22600%22 cy=%22200%22 r=%22150%22 fill=%22%232563eb%22 opacity=%220.1%22/%3E%3C/svg%3E');">
                    </div>
                    <div class="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
                    <div class="relative z-10 w-full flex flex-col md:flex-row md:items-end justify-between gap-md">
                        <div>
                            <span class="inline-block px-sm py-1 bg-primary/20 text-primary font-label-md text-label-md rounded-full mb-2 backdrop-blur-md border border-primary/30">
                                Próxima Fase
                            </span>
                            <h3 class="font-display-lg text-[28px] md:text-display-lg leading-tight text-white mb-2">
                                Bloco de<br/>Hipertrofia - Semana 3
                            </h3>
                        </div>
                        <button onclick="router.render('treinos')" class="bg-primary-container text-on-primary-container hover:bg-primary hover:text-on-primary transition-colors min-h-[56px] rounded-xl px-xl py-sm font-label-md text-label-md flex items-center justify-center gap-2 active:scale-95 duration-200 shadow-lg shadow-primary-container/20">
                            <span class="material-symbols-outlined icon-fill">play_arrow</span>
                            Iniciar Treino
                        </button>
                    </div>
                </section>

                <section class="grid grid-cols-2 md:grid-cols-4 gap-md">
                    <div class="bg-surface rounded-xl p-md border border-outline-variant/20 relative overflow-hidden">
                        <div class="absolute top-0 right-0 w-20 h-20 bg-primary/5 rounded-bl-full -mr-4 -mt-4"></div>
                        <span class="font-label-md text-label-md text-on-surface-variant flex items-center gap-1">
                            <span class="material-symbols-outlined text-[18px]">calendar_month</span>
                            Treinos
                        </span>
                        <p class="font-stats-xl text-stats-xl text-on-surface mt-1">${stats.totalWorkouts}</p>
                    </div>
                    <div class="bg-surface rounded-xl p-md border border-outline-variant/20 relative overflow-hidden">
                        <div class="absolute top-0 right-0 w-20 h-20 bg-error/5 rounded-bl-full -mr-4 -mt-4"></div>
                        <span class="font-label-md text-label-md text-on-surface-variant flex items-center gap-1">
                            <span class="material-symbols-outlined text-[18px]">local_fire_department</span>
                            Streak
                        </span>
                        <p class="font-stats-xl text-stats-xl text-on-surface mt-1">${stats.streak}</p>
                    </div>
                    <div class="col-span-2 bg-gradient-to-br from-surface to-surface-container-highest rounded-xl p-md border border-outline-variant/20">
                        <span class="font-label-md text-label-md text-on-surface-variant flex items-center gap-1 mb-2">
                            <span class="material-symbols-outlined text-[18px]">skip_next</span>
                            Próximo Exercício
                        </span>
                        ${nextExercise ? `
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="font-headline-md text-headline-md text-on-surface">${nextExercise.name}</p>
                                    <p class="font-body-md text-body-md text-primary mt-1">${nextExercise.sets}x ${nextExercise.reps}</p>
                                </div>
                                <div class="w-12 h-12 rounded-full bg-surface-variant flex items-center justify-center">
                                    <span class="material-symbols-outlined text-on-surface-variant">fitness_center</span>
                                </div>
                            </div>
                        ` : '<p class="text-on-surface-variant">Nenhum exercício pendente</p>'}
                    </div>
                </section>

                <section class="flex flex-col gap-md">
                    <div class="flex justify-between items-end">
                        <h3 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">Treino do Dia</h3>
                        <button onclick="router.render('treinos')" class="font-label-md text-label-md text-primary hover:underline">Ver Todos</button>
                    </div>
                    ${DATA.workouts.length ? `
                        <div class="bg-surface rounded-xl p-lg border border-outline-variant/20 flex flex-col md:flex-row gap-lg items-center relative overflow-hidden group hover:border-primary/50 transition-colors cursor-pointer" onclick="router.render('treinos', { workoutId: ${DATA.workouts[0].id} })">
                            <div class="absolute inset-0 bg-gradient-to-r from-transparent to-primary/5 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            <div class="w-full md:w-1/3 h-48 md:h-full rounded-lg overflow-hidden relative bg-surface-variant flex items-center justify-center">
                                <span class="material-symbols-outlined text-6xl text-outline">fitness_center</span>
                            </div>
                            <div class="flex-1 w-full flex flex-col gap-sm z-10">
                                <div class="flex gap-2 flex-wrap">
                                    <span class="px-2 py-1 bg-surface-variant text-on-surface-variant rounded font-label-md text-[12px]">${DATA.workouts[0].difficulty}</span>
                                    <span class="px-2 py-1 bg-surface-variant text-on-surface-variant rounded font-label-md text-[12px]">${DATA.workouts[0].time}</span>
                                    <span class="px-2 py-1 bg-surface-variant text-on-surface-variant rounded font-label-md text-[12px]">${DATA.workouts[0].exercises.length} exercícios</span>
                                </div>
                                <h4 class="font-headline-md text-headline-md text-on-surface">${DATA.workouts[0].name}</h4>
                                <p class="font-body-md text-body-md text-on-surface-variant line-clamp-2">${DATA.workouts[0].observations || 'Treino completo para o dia'}</p>
                            </div>
                        </div>
                    ` : ''}
                </section>
            </div>
        `;
    }

    getNextExercise() {
        const completed = Store.getCompleted();
        const available = DATA.exercises.filter(e => !completed.includes(e.id));
        return available.length ? available[0] : DATA.exercises[0];
    }

    renderTreinos(container, params = null) {
        if (params && params.workoutId) {
            this.currentWorkoutId = params.workoutId;
            this.renderWorkoutDetail(container, params.workoutId);
            return;
        }

        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <div class="flex flex-col gap-sm">
                    <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">Biblioteca de Treinos</h2>
                    <p class="text-on-surface-variant">Encontre a rotina perfeita para seus objetivos.</p>
                </div>

                <div class="relative">
                    <span class="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 text-outline">search</span>
                    <input id="workoutSearch" type="text" placeholder="Buscar treinos..." class="w-full bg-surface-container text-on-surface border-none rounded-lg pl-10 pr-md py-sm focus:ring-2 focus:ring-primary font-body-md text-body-md">
                </div>

                <div class="flex overflow-x-auto gap-sm pb-sm hide-scrollbar">
                    <button class="group-filter px-md py-xs rounded-full bg-primary-container text-on-primary-container font-label-md text-label-md whitespace-nowrap" data-group="all">Todos</button>
                    <button class="group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Peito">Peito</button>
                    <button class="group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Costas">Costas</button>
                    <button class="group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Pernas">Pernas</button>
                    <button class="group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Ombro">Ombro</button>
                    <button class="group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Bíceps">Bíceps</button>
                    <button class="group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Tríceps">Tríceps</button>
                </div>

                <div id="workoutGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-md">
                    ${DATA.workouts.map(w => `
                        <div class="workout-card bg-surface rounded-xl border border-outline-variant/30 overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group relative" data-group="${w.group}" data-name="${w.name.toLowerCase()}">
                            <div class="h-32 bg-surface-variant relative overflow-hidden">
                                ${w.image ?
                `<img src="${w.image}" class="absolute inset-0 w-full h-full object-cover">
                                     <div class="absolute inset-0 bg-black/30"></div>` :
                `<div class="absolute inset-0 bg-gradient-to-br from-surface-variant to-surface-container flex items-center justify-center">
                                        <span class="material-symbols-outlined text-5xl text-outline opacity-30">fitness_center</span>
                                    </div>`
            }
                                <button class="absolute top-sm right-sm text-on-surface hover:text-primary z-10 bg-surface/50 rounded-full p-1 backdrop-blur-sm" onclick="event.stopPropagation(); toggleFavoriteWorkout(${w.id})">
                                    <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' ${Store.isFavorite('workouts', w.id) ? 1 : 0}">
                                        ${Store.isFavorite('workouts', w.id) ? 'favorite' : 'favorite_border'}
                                    </span>
                                </button>
                                <div class="absolute bottom-sm left-sm bg-primary/20 backdrop-blur-md px-2 py-1 rounded text-primary font-label-md text-[10px] uppercase">${w.difficulty}</div>
                            </div>
                            <div class="p-md" onclick="router.render('treinos', { workoutId: ${w.id} })">
                                <h3 class="font-headline-md text-headline-md text-on-surface mb-xs">${w.name}</h3>
                                <div class="flex items-center gap-md text-on-surface-variant mb-md text-sm flex-wrap">
                                    <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">fitness_center</span> ${w.exercises.length} Exercícios</span>
                                    <span class="flex items-center gap-1"><span class="material-symbols-outlined text-sm">schedule</span> ${w.time}</span>
                                </div>
                                <div class="flex items-center justify-between mt-auto">
                                    <div class="flex gap-1">
                                        ${w.exercises.slice(0, 3).map(() => `<span class="w-6 h-1 bg-primary rounded-full"></span>`).join('')}
                                        ${w.exercises.length > 3 ? `<span class="w-6 h-1 bg-surface-variant rounded-full"></span>` : ''}
                                    </div>
                                    <span class="text-xs text-outline font-label-md">${w.group.split(',').slice(0, 2).join(' • ')}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        document.querySelectorAll('.group-filter').forEach(btn => {
            btn.addEventListener('click', () => {
                const group = btn.dataset.group;
                document.querySelectorAll('.group-filter').forEach(b => {
                    b.className = 'group-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap';
                });
                btn.className = 'group-filter px-md py-xs rounded-full bg-primary-container text-on-primary-container font-label-md text-label-md whitespace-nowrap';

                document.querySelectorAll('.workout-card').forEach(card => {
                    if (group === 'all' || card.dataset.group.includes(group)) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });

        document.getElementById('workoutSearch').addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            document.querySelectorAll('.workout-card').forEach(card => {
                const name = card.dataset.name;
                card.style.display = name.includes(term) ? '' : 'none';
            });
        });
    }

    renderWorkoutDetail(container, workoutId) {
        const workout = DATA.workouts.find(w => w.id === workoutId);
        if (!workout) {
            this.renderTreinos(container);
            return;
        }

        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <button onclick="router.render('treinos')" class="back-button flex items-center gap-2 text-on-surface-variant hover:text-primary transition">
                    <span class="material-symbols-outlined">arrow_back</span>
                    <span class="font-label-md text-label-md">Voltar aos Treinos</span>
                </button>

                <div class="bg-surface rounded-xl p-lg border border-outline-variant/20">
                    <div class="flex flex-col md:flex-row md:items-start justify-between gap-md">
                        <div>
                            <h2 class="font-display-lg text-[28px] md:text-display-lg text-on-surface">${workout.name}</h2>
                            <div class="flex flex-wrap gap-2 mt-2">
                                <span class="px-3 py-1 bg-primary/20 text-primary rounded-full font-label-md text-label-md">${workout.difficulty}</span>
                                <span class="px-3 py-1 bg-surface-variant text-on-surface-variant rounded-full font-label-md text-label-md flex items-center gap-1">
                                    <span class="material-symbols-outlined text-sm">schedule</span> ${workout.time}
                                </span>
                                <span class="px-3 py-1 bg-surface-variant text-on-surface-variant rounded-full font-label-md text-label-md">
                                    ${workout.exercises.length} exercícios
                                </span>
                            </div>
                            <p class="text-on-surface-variant mt-3">${workout.group}</p>
                            ${workout.observations ? `<p class="text-on-surface-variant text-sm mt-1">💡 ${workout.observations}</p>` : ''}
                        </div>
                        <button onclick="startWorkoutTimer(${workout.id})" class="bg-primary-container text-on-primary-container hover:bg-primary hover:text-on-primary transition-colors min-h-[48px] rounded-xl px-xl py-sm font-label-md text-label-md flex items-center justify-center gap-2 active:scale-95 duration-200 shadow-lg shadow-primary-container/20">
                            <span class="material-symbols-outlined icon-fill">play_arrow</span>
                            Iniciar Treino
                        </button>
                    </div>
                </div>

                <div id="workoutTimer" class="timer-container hidden">
                    <div class="flex items-center gap-4">
                        <span class="material-symbols-outlined text-primary">timer</span>
                        <span class="timer-display" id="timerDisplay">00:00:00</span>
                    </div>
                    <div class="timer-controls">
                        <button onclick="pauseTimer()" id="pauseTimerBtn" class="primary">
                            <span class="material-symbols-outlined text-sm">pause</span> Pausar
                        </button>
                        <button onclick="resetTimer()" class="danger">
                            <span class="material-symbols-outlined text-sm">restart_alt</span> Resetar
                        </button>
                    </div>
                </div>

                <div class="bg-surface rounded-xl border border-outline-variant/20 overflow-hidden">
                    <div class="p-lg border-b border-outline-variant/20">
                        <h3 class="font-headline-md text-headline-md text-on-surface">Exercícios</h3>
                    </div>
                    <div class="divide-y divide-outline-variant/10">
                        ${workout.exercises.map((ex, index) => {
            const exerciseData = DATA.exercises.find(e => e.name === ex.name);
            const imageUrl = exerciseData && exerciseData.image ? exerciseData.image : '';

            return `
                                <div class="exercise-item-with-image">
                                    <div class="exercise-thumb">
                                        ${imageUrl ?
                    `<img src="${imageUrl}" alt="${ex.name}" loading="lazy">` :
                    `<div class="w-full h-full flex items-center justify-center bg-surface-variant">
                                                <span class="material-symbols-outlined text-4xl text-outline">fitness_center</span>
                                            </div>`
                }
                                    </div>
                                    <div class="exercise-info">
                                        <div class="flex items-start justify-between">
                                            <div>
                                                <div class="flex items-center gap-2">
                                                    <span class="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">${index + 1}</span>
                                                    <span class="exercise-name">${ex.name}</span>
                                                </div>
                                                <span class="exercise-variation">${ex.variation || ''}</span>
                                            </div>
                                            <button onclick="markExerciseComplete('${ex.name}')" class="text-on-surface-variant hover:text-green-400 transition">
                                                <span class="material-symbols-outlined">check_circle</span>
                                            </button>
                                        </div>
                                        <div class="exercise-details">
                                            <span class="exercise-set-badge px-3 py-1 rounded-full text-sm font-medium text-primary">
                                                ${ex.sets} × ${ex.reps}
                                            </span>
                                            ${ex.rest > 0 ? `
                                                <span class="rest-timer flex items-center gap-1">
                                                    <span class="material-symbols-outlined text-sm">timer</span>
                                                    ${ex.rest}s
                                                </span>
                                            ` : ''}
                                        </div>
                                    </div>
                                </div>
                            `;
        }).join('')}
                    </div>
                </div>

                <button id="finishWorkoutBtn" onclick="completeWorkout('${workout.name}', ${workout.exercises.length})" class="finish-workout-btn" disabled>
                    <span class="material-symbols-outlined">check_circle</span>
                    Finalizar Treino
                </button>
            </div>
        `;
    }

    renderExercicios(container) {
        const completed = Store.getCompleted();
        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-sm">
                    <div>
                        <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">Biblioteca de Exercícios</h2>
                        <p class="text-on-surface-variant">Explore os exercícios e marque os concluídos.</p>
                    </div>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 text-outline">search</span>
                        <input id="exerciseSearch" type="text" placeholder="Buscar..." class="w-full sm:w-64 bg-surface-container text-on-surface border-none rounded-lg pl-10 pr-md py-sm focus:ring-2 focus:ring-primary font-body-md text-body-md">
                    </div>
                </div>

                <div class="flex overflow-x-auto gap-sm pb-sm hide-scrollbar">
                    <button class="ex-filter px-md py-xs rounded-full bg-primary-container text-on-primary-container font-label-md text-label-md whitespace-nowrap" data-group="all">Todos</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Peito">Peito</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Costas">Costas</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Pernas">Pernas</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Ombro">Ombro</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Bíceps">Bíceps</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Tríceps">Tríceps</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Abdômen">Abdômen</button>
                    <button class="ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap" data-group="Cardio">Cardio</button>
                </div>

                <div id="exerciseGrid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-md">
                    ${DATA.exercises.map(e => `
                        <div class="ex-card bg-surface rounded-xl border border-outline-variant/30 overflow-hidden hover:border-primary/50 transition-colors cursor-pointer" data-group="${e.group}" data-name="${e.name.toLowerCase()}" onclick="showExerciseDetail(${e.id})">
                            <div class="relative h-40 bg-surface-variant">
                                ${e.image ?
                `<img src="${e.image}" alt="${e.name}" class="w-full h-full object-cover">` :
                `<div class="w-full h-full flex items-center justify-center"><span class="material-symbols-outlined text-5xl text-outline">fitness_center</span></div>`
            }
                                <div class="absolute top-2 right-2 flex gap-1">
                                    ${completed.includes(e.id) ? '<span class="bg-green-500/80 text-white px-2 py-0.5 rounded-full text-xs">✅</span>' : ''}
                                    <button onclick="event.stopPropagation(); toggleFavoriteExercise(${e.id})" class="bg-black/50 text-white hover:text-primary transition rounded-full p-1 backdrop-blur-sm">
                                        <span class="material-symbols-outlined text-sm" style="font-variation-settings: 'FILL' ${Store.isFavorite('exercises', e.id) ? 1 : 0}">
                                            ${Store.isFavorite('exercises', e.id) ? 'favorite' : 'favorite_border'}
                                        </span>
                                    </button>
                                </div>
                            </div>
                            <div class="p-md">
                                <h3 class="font-headline-md text-headline-md text-on-surface">${e.name}</h3>
                                <p class="text-sm text-on-surface-variant">${e.group}</p>
                                <div class="flex flex-wrap gap-2 mt-2 text-sm text-on-surface-variant">
                                    <span class="px-2 py-0.5 bg-surface-variant rounded-full text-xs">${e.difficulty}</span>
                                    <span><span class="material-symbols-outlined text-sm align-middle">fitness_center</span> ${e.sets}x ${e.reps}</span>
                                    <span><span class="material-symbols-outlined text-sm align-middle">timer</span> ${e.rest}s</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        document.querySelectorAll('.ex-filter').forEach(btn => {
            btn.addEventListener('click', () => {
                const group = btn.dataset.group;
                document.querySelectorAll('.ex-filter').forEach(b => {
                    b.className = 'ex-filter px-md py-xs rounded-full bg-surface-container border border-outline-variant/30 text-on-surface hover:bg-surface-variant transition-colors font-label-md text-label-md whitespace-nowrap';
                });
                btn.className = 'ex-filter px-md py-xs rounded-full bg-primary-container text-on-primary-container font-label-md text-label-md whitespace-nowrap';

                document.querySelectorAll('.ex-card').forEach(card => {
                    if (group === 'all' || card.dataset.group === group) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });

        document.getElementById('exerciseSearch').addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            document.querySelectorAll('.ex-card').forEach(card => {
                card.style.display = card.dataset.name.includes(term) ? '' : 'none';
            });
        });
    }

    renderProgresso(container) {
        const stats = Store.getStats();
        const history = Store.getHistory();

        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <div>
                    <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">📊 Progresso</h2>
                    <p class="text-on-surface-variant">Acompanhe sua evolução</p>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-md">
                    <div class="bg-surface rounded-xl p-md border border-outline-variant/20">
                        <p class="text-on-surface-variant text-sm">Total Treinos</p>
                        <p class="font-stats-xl text-stats-xl text-primary">${stats.totalWorkouts}</p>
                    </div>
                    <div class="bg-surface rounded-xl p-md border border-outline-variant/20">
                        <p class="text-on-surface-variant text-sm">Exercícios</p>
                        <p class="font-stats-xl text-stats-xl text-tertiary">${stats.totalExercises}</p>
                    </div>
                    <div class="bg-surface rounded-xl p-md border border-outline-variant/20">
                        <p class="text-on-surface-variant text-sm">Streak</p>
                        <p class="font-stats-xl text-stats-xl text-secondary">🔥 ${stats.streak}</p>
                    </div>
                    <div class="bg-surface rounded-xl p-md border border-outline-variant/20">
                        <p class="text-on-surface-variant text-sm">Tempo Total</p>
                        <p class="font-stats-xl text-stats-xl text-on-surface">${Math.floor(stats.totalTime / 60)}h</p>
                    </div>
                </div>

                <div class="bg-surface rounded-xl border border-outline-variant/20 p-lg">
                    <h3 class="font-headline-md text-headline-md text-on-surface mb-4">📋 Histórico</h3>
                    ${history.length ? history.slice(0, 10).map(h => `
                        <div class="flex items-center justify-between py-3 border-b border-outline-variant/10 last:border-0">
                            <div>
                                <p class="font-medium">${h.workout || 'Treino'}</p>
                                <p class="text-xs text-on-surface-variant">${new Date(h.date).toLocaleString()}</p>
                            </div>
                            <span class="text-sm text-on-surface-variant">${h.exercises || 0} exercícios • ${h.time || 0}min</span>
                        </div>
                    `).join('') : '<p class="text-on-surface-variant text-center py-8">Nenhum histórico ainda</p>'}
                </div>
            </div>
        `;
    }

    renderScanner(container) {
        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <div>
                    <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">📷 Scanner de Equipamentos</h2>
                    <p class="text-on-surface-variant">Aponte a câmera para o QR Code do equipamento</p>
                </div>

                <div class="glass-panel rounded-xl p-lg">
                    <div id="scannerContainer" class="relative aspect-video bg-black rounded-lg overflow-hidden">
                        <video id="scannerVideo" class="w-full h-full object-cover" autoplay playsinline></video>
                        <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <div class="scan-frame w-4/5 h-3/4 rounded-lg relative">
                                <div class="absolute top-0 left-0 w-full h-full border-2 border-primary/50 rounded-lg"></div>
                                <div class="absolute top-0 left-0 w-full h-0.5 bg-primary animate-scan"></div>
                                <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary"></div>
                                <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-primary"></div>
                                <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-primary"></div>
                                <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary"></div>
                            </div>
                        </div>
                        <div id="scannerStatus" class="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/75 backdrop-blur-md px-6 py-2 rounded-full text-sm text-white border border-outline-variant/30">
                            🔍 Escaneando equipamento...
                        </div>
                    </div>
                    <div class="flex gap-2 mt-4 justify-center flex-wrap">
                        <button onclick="toggleCamera()" class="bg-surface-variant text-on-surface px-4 py-2 rounded-lg text-sm hover:bg-surface-container-high transition flex items-center gap-2">
                            <span class="material-symbols-outlined text-sm">cameraswitch</span>
                            Ligar/Desligar
                        </button>
                        <button onclick="switchCamera()" class="bg-surface-variant text-on-surface px-4 py-2 rounded-lg text-sm hover:bg-surface-container-high transition flex items-center gap-2">
                            <span class="material-symbols-outlined text-sm">flip_camera_android</span>
                            Trocar Câmera
                        </button>
                    </div>
                </div>

                <div id="equipmentResult" class="hidden"></div>
            </div>
        `;

        if (window.scanner) {
            window.scanner.stop();
        }
        window.scanner = new Scanner('scannerVideo', 'scannerStatus', 'equipmentResult');
        window.scanner.init();
    }

    renderPerfil(container) {
        const profile = Store.getProfile();
        const stats = Store.getStats();
        const imc = profile.weight && profile.height ?
            (profile.weight / ((profile.height / 100) ** 2)).toFixed(1) : '--';

        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <div>
                    <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">👤 Perfil do Atleta</h2>
                    <p class="text-on-surface-variant">Gerencie seus dados fisiológicos</p>
                </div>

                <div class="glass-panel rounded-xl p-lg md:p-xl flex flex-col md:flex-row items-center md:items-start gap-lg relative overflow-hidden">
                    <div class="absolute -top-24 -right-24 w-64 h-64 bg-primary/10 rounded-full blur-3xl pointer-events-none"></div>
                    <div class="relative group">
                        <div class="w-32 h-32 md:w-40 md:h-40 rounded-full bg-surface-variant flex items-center justify-center text-6xl text-primary border-4 border-primary/30">
                            ${profile.name ? profile.name[0].toUpperCase() : '?'}
                        </div>
                    </div>
                    <div class="flex-1 text-center md:text-left">
                        <h2 class="font-display-lg text-[28px] md:text-display-lg text-on-surface">${profile.name || 'Não cadastrado'}</h2>
                        <div class="flex flex-wrap items-center justify-center md:justify-start gap-2 mt-2">
                            <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/20 text-primary border border-primary/30 font-label-md text-label-md">
                                <span class="material-symbols-outlined text-sm icon-fill">star</span>
                                ${profile.goal || 'Sem objetivo'}
                            </span>
                            <span class="text-on-surface-variant text-sm flex items-center gap-1">
                                <span class="material-symbols-outlined text-sm">person</span>
                                ${profile.level || 'Nível não definido'}
                            </span>
                        </div>
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
                            <div><span class="text-on-surface-variant text-sm">Idade</span><p class="font-bold">${profile.age || '--'}</p></div>
                            <div><span class="text-on-surface-variant text-sm">Altura</span><p class="font-bold">${profile.height || '--'} cm</p></div>
                            <div><span class="text-on-surface-variant text-sm">Peso</span><p class="font-bold">${profile.weight || '--'} kg</p></div>
                            <div><span class="text-on-surface-variant text-sm">IMC</span><p class="font-bold">${imc}</p></div>
                        </div>
                    </div>
                </div>

                <button onclick="editProfile()" class="w-full bg-primary-container text-on-primary-container hover:bg-primary hover:text-on-primary transition-colors font-bold py-4 rounded-xl min-h-[56px]">
                    <span class="material-symbols-outlined align-middle mr-2">edit</span>
                    Editar Perfil
                </button>

                <div class="bg-surface rounded-xl p-lg border border-outline-variant/20">
                    <h4 class="font-headline-md text-headline-md text-on-surface mb-3">📊 Estatísticas</h4>
                    <div class="grid grid-cols-3 gap-3 text-center">
                        <div><p class="font-stats-xl text-stats-xl text-primary">${stats.totalWorkouts}</p><p class="text-xs text-on-surface-variant">Treinos</p></div>
                        <div><p class="font-stats-xl text-stats-xl text-secondary">${stats.streak}</p><p class="text-xs text-on-surface-variant">Streak</p></div>
                        <div><p class="font-stats-xl text-stats-xl text-tertiary">${stats.totalExercises}</p><p class="text-xs text-on-surface-variant">Exercícios</p></div>
                    </div>
                </div>
            </div>
        `;
    }

    renderConfiguracoes(container) {
        container.innerHTML = `
            <div class="animate-slide-up space-y-lg">
                <div>
                    <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">⚙️ Configurações</h2>
                    <p class="text-on-surface-variant">Gerencie seus dados e preferências</p>
                </div>

                <div class="glass-panel rounded-xl p-lg space-y-4">
                    <h3 class="font-headline-md text-headline-md text-on-surface border-b border-outline-variant/30 pb-3">Dados</h3>
                    <button onclick="if(confirm('Limpar todo o histórico?')) { Store.clearAll(); location.reload(); }" class="w-full bg-error-container/20 text-error hover:bg-error-container/30 transition px-4 py-3 rounded-lg text-sm text-left flex items-center gap-2">
                        <span class="material-symbols-outlined">delete_forever</span>
                        Limpar Histórico
                    </button>
                    <button onclick="if(confirm('Resetar todos os dados?')) { Store.clearAll(); location.reload(); }" class="w-full bg-error-container/20 text-error hover:bg-error-container/30 transition px-4 py-3 rounded-lg text-sm text-left flex items-center gap-2">
                        <span class="material-symbols-outlined">restart_alt</span>
                        Resetar Dados
                    </button>
                </div>

                <div class="glass-panel rounded-xl p-lg space-y-4">
                    <h3 class="font-headline-md text-headline-md text-on-surface border-b border-outline-variant/30 pb-3">Exportar/Importar</h3>
                    <button onclick="exportData()" class="w-full bg-primary-container/20 text-primary hover:bg-primary-container/30 transition px-4 py-3 rounded-lg text-sm text-left flex items-center gap-2">
                        <span class="material-symbols-outlined">download</span>
                        Exportar Dados (JSON)
                    </button>
                    <button onclick="document.getElementById('importFile').click()" class="w-full bg-primary-container/20 text-primary hover:bg-primary-container/30 transition px-4 py-3 rounded-lg text-sm text-left flex items-center gap-2">
                        <span class="material-symbols-outlined">upload</span>
                        Importar Dados (JSON)
                    </button>
                    <input type="file" id="importFile" accept=".json" class="hidden" onchange="importData(event)">
                </div>

                <div class="glass-panel rounded-xl p-lg">
                    <h3 class="font-headline-md text-headline-md text-on-surface border-b border-outline-variant/30 pb-3">Sobre</h3>
                    <p class="text-on-surface-variant text-sm">Apex Performance v2.0</p>
                    <p class="text-on-surface-variant text-sm">Academia inteligente com localStorage</p>
                </div>
            </div>
        `;
    }
}

// ===================== TIMER =====================
let timerInterval = null;
let timerSeconds = 0;
let isTimerRunning = false;

function startWorkoutTimer(workoutId) {
    const timerElement = document.getElementById('workoutTimer');
    const display = document.getElementById('timerDisplay');
    const finishBtn = document.getElementById('finishWorkoutBtn');

    if (timerElement) {
        timerElement.classList.remove('hidden');
    }

    if (finishBtn) {
        finishBtn.disabled = false;
    }

    if (!isTimerRunning) {
        isTimerRunning = true;
        timerInterval = setInterval(() => {
            timerSeconds++;
            display.textContent = formatTime(timerSeconds);
            display.className = 'timer-display running';
        }, 1000);
    }

    const startBtn = document.querySelector('[onclick*="startWorkoutTimer"]');
    if (startBtn) {
        startBtn.innerHTML = `
            <span class="material-symbols-outlined icon-fill">play_arrow</span>
            Treino em Andamento
        `;
        startBtn.disabled = true;
        startBtn.className = 'bg-green-500/20 text-green-400 min-h-[48px] rounded-xl px-xl py-sm font-label-md text-label-md flex items-center justify-center gap-2 opacity-70 cursor-not-allowed';
    }
}

function pauseTimer() {
    if (isTimerRunning) {
        clearInterval(timerInterval);
        isTimerRunning = false;
        const display = document.getElementById('timerDisplay');
        if (display) display.className = 'timer-display paused';
        const btn = document.getElementById('pauseTimerBtn');
        if (btn) {
            btn.innerHTML = `<span class="material-symbols-outlined text-sm">play_arrow</span> Continuar`;
            btn.onclick = resumeTimer;
        }
    }
}

function resumeTimer() {
    if (!isTimerRunning) {
        isTimerRunning = true;
        timerInterval = setInterval(() => {
            timerSeconds++;
            const display = document.getElementById('timerDisplay');
            if (display) {
                display.textContent = formatTime(timerSeconds);
                display.className = 'timer-display running';
            }
        }, 1000);
        const btn = document.getElementById('pauseTimerBtn');
        if (btn) {
            btn.innerHTML = `<span class="material-symbols-outlined text-sm">pause</span> Pausar`;
            btn.onclick = pauseTimer;
        }
    }
}

function resetTimer() {
    clearInterval(timerInterval);
    isTimerRunning = false;
    timerSeconds = 0;
    const display = document.getElementById('timerDisplay');
    if (display) {
        display.textContent = '00:00:00';
        display.className = 'timer-display';
    }
    const btn = document.getElementById('pauseTimerBtn');
    if (btn) {
        btn.innerHTML = `<span class="material-symbols-outlined text-sm">pause</span> Pausar`;
        btn.onclick = pauseTimer;
    }
}

function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// ===================== SCANNER =====================
class Scanner {
    constructor(videoId, statusId, resultId) {
        this.video = document.getElementById(videoId);
        this.status = document.getElementById(statusId);
        this.result = document.getElementById(resultId);
        this.stream = null;
        this.isRunning = false;
        this.facingMode = 'environment';
        this.scanTimeout = null;
    }

    async init() {
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facingMode }
            });
            this.video.srcObject = this.stream;
            this.isRunning = true;
            this.startScanning();
        } catch (err) {
            this.status.textContent = '❌ Câmera não disponível. Permita o acesso.';
            this.status.className = 'absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-error/20 text-error px-6 py-2 rounded-full text-sm border border-error/30';
        }
    }

    startScanning() {
        if (this.scanTimeout) clearTimeout(this.scanTimeout);
        this.status.textContent = '🔍 Escaneando equipamento...';
        this.status.className = 'absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/75 backdrop-blur-md px-6 py-2 rounded-full text-sm text-white border border-outline-variant/30';

        this.scanTimeout = setTimeout(() => {
            this.simulateScan();
        }, 2000 + Math.random() * 2000);
    }

    simulateScan() {
        this.status.textContent = '✅ Equipamento identificado com sucesso!';
        this.status.className = 'absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-green-500/20 text-green-400 px-6 py-2 rounded-full text-sm border border-green-500/30';

        const equipment = DATA.equipments[Math.floor(Math.random() * DATA.equipments.length)];
        this.showEquipment(equipment);
    }

    showEquipment(equipment) {
        this.result.className = 'mt-4 animate-slide-up';
        this.result.innerHTML = `
            <div class="glass-panel rounded-xl p-lg border border-primary/30">
                <h3 class="text-xl font-bold text-primary">${equipment.name}</h3>
                <div class="grid grid-cols-2 gap-2 mt-3 text-sm">
                    <div><span class="text-on-surface-variant">Grupo:</span> ${equipment.group}</div>
                    <div><span class="text-on-surface-variant">Dificuldade:</span> ${equipment.difficulty}</div>
                    <div><span class="text-on-surface-variant">Séries:</span> ${equipment.sets}</div>
                    <div><span class="text-on-surface-variant">Repetições:</span> ${equipment.reps}</div>
                    <div><span class="text-on-surface-variant">Descanso:</span> ${equipment.rest}s</div>
                    <div><span class="text-on-surface-variant">Carga:</span> ${equipment.load}</div>
                </div>
                <div class="mt-3 space-y-1">
                    <p class="text-on-surface-variant text-sm"><strong>Músculos:</strong> ${equipment.muscles.join(', ')}</p>
                    <p class="text-on-surface-variant text-sm"><strong>Dicas:</strong> ${equipment.tips}</p>
                    <p class="text-on-surface-variant text-sm"><strong>Benefícios:</strong> ${equipment.benefits}</p>
                </div>
                <button onclick="alert('Iniciando exercício: ${equipment.name}')" class="w-full mt-3 bg-primary-container text-on-primary-container hover:bg-primary hover:text-on-primary transition-colors font-bold py-3 rounded-lg min-h-[48px]">
                    <span class="material-symbols-outlined align-middle mr-2">play_arrow</span>
                    Iniciar Exercício
                </button>
            </div>
        `;
    }

    toggle() {
        if (this.isRunning) {
            this.stop();
        } else {
            this.init();
        }
    }

    stop() {
        if (this.stream) {
            this.stream.getTracks().forEach(t => t.stop());
            this.isRunning = false;
            this.video.srcObject = null;
            this.status.textContent = '📷 Câmera desligada';
            this.status.className = 'absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/75 backdrop-blur-md px-6 py-2 rounded-full text-sm text-white border border-outline-variant/30';
        }
        if (this.scanTimeout) clearTimeout(this.scanTimeout);
    }

    switchCamera() {
        this.facingMode = this.facingMode === 'environment' ? 'user' : 'environment';
        this.stop();
        this.init();
    }
}

// ===================== GLOBALS =====================
let router;

window.toggleFavoriteWorkout = function (id) {
    Store.toggleFavorite('workouts', id);
    router.render('treinos');
};

window.toggleFavoriteExercise = function (id) {
    Store.toggleFavorite('exercises', id);
    router.render('exercicios');
};

window.showExerciseDetail = function (id) {
    const exercise = DATA.exercises.find(e => e.id === id);
    if (!exercise) return;
    const isComplete = Store.getCompleted().includes(id);
    const isFav = Store.isFavorite('exercises', id);

    alert(`🏃 ${exercise.name}\n\nGrupo: ${exercise.group}\nMúsculos: ${exercise.muscles.join(', ')}\nEquipamento: ${exercise.equipment}\nSéries: ${exercise.sets}\nRepetições: ${exercise.reps}\nDescanso: ${exercise.rest}s\nDificuldade: ${exercise.difficulty}\n\n${isComplete ? '✅ Concluído' : '⏳ Pendente'}\n${isFav ? '⭐ Favorito' : ''}`);

    Store.toggleCompleted(id);
    router.render('exercicios');
};

window.markExerciseComplete = function (name) {
    const exercise = DATA.exercises.find(e => e.name === name);
    if (exercise) {
        Store.toggleCompleted(exercise.id);
        alert(`✅ ${name} marcado como concluído!`);
    }
};

window.completeWorkout = function (name, count) {
    clearInterval(timerInterval);
    isTimerRunning = false;

    const timeInMinutes = Math.ceil(timerSeconds / 60);
    Store.addHistory({
        workout: name,
        exercises: count,
        time: timeInMinutes
    });

    alert(`🏋️ Treino "${name}" finalizado com sucesso!\n\n${count} exercícios concluídos\n⏱️ Tempo: ${formatTime(timerSeconds)}`);

    timerSeconds = 0;
    const display = document.getElementById('timerDisplay');
    if (display) {
        display.textContent = '00:00:00';
        display.className = 'timer-display';
    }

    router.render('home');
};

window.editProfile = function () {
    const profile = Store.getProfile();
    const fields = [
        { label: 'Nome', key: 'name', type: 'text' },
        { label: 'Idade', key: 'age', type: 'number' },
        { label: 'Sexo', key: 'gender', type: 'select', options: ['', 'Masculino', 'Feminino', 'Outro'] },
        { label: 'Altura (cm)', key: 'height', type: 'number' },
        { label: 'Peso (kg)', key: 'weight', type: 'number' },
        { label: 'Objetivo', key: 'goal', type: 'select', options: ['', 'Emagrecer', 'Hipertrofia', 'Condicionamento', 'Definição'] },
        { label: 'Nível', key: 'level', type: 'select', options: ['', 'Iniciante', 'Intermediário', 'Avançado'] },
    ];

    let form = fields.map(f => {
        const value = profile[f.key] || '';
        if (f.type === 'select') {
            const options = f.options.map(o => `<option value="${o}" ${o === value ? 'selected' : ''}>${o || 'Selecione...'}</option>`).join('');
            return `<div class="flex flex-col gap-1"><label class="text-sm text-on-surface-variant">${f.label}</label><select id="edit_${f.key}" class="w-full bg-surface-container text-on-surface border-none rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary">${options}</select></div>`;
        }
        return `<div class="flex flex-col gap-1"><label class="text-sm text-on-surface-variant">${f.label}</label><input id="edit_${f.key}" type="${f.type}" value="${value}" class="w-full bg-surface-container text-on-surface border-none rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary"></div>`;
    }).join('');

    document.getElementById('contentArea').innerHTML = `
        <div class="animate-slide-up space-y-lg">
            <h2 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">✏️ Editar Perfil</h2>
            <div class="glass-panel rounded-xl p-lg">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    ${form}
                </div>
                <div class="flex gap-2 mt-6">
                    <button onclick="saveProfile()" class="flex-1 bg-primary-container text-on-primary-container hover:bg-primary hover:text-on-primary transition-colors font-bold py-3 rounded-xl min-h-[48px]">
                        <span class="material-symbols-outlined align-middle mr-2">save</span>
                        Salvar
                    </button>
                    <button onclick="router.render('perfil')" class="flex-1 bg-surface-variant text-on-surface hover:bg-surface-container-high transition-colors font-bold py-3 rounded-xl min-h-[48px]">
                        Cancelar
                    </button>
                </div>
            </div>
        </div>
    `;
};

window.saveProfile = function () {
    const fields = ['name', 'age', 'gender', 'height', 'weight', 'goal', 'level'];
    const profile = {};
    fields.forEach(f => {
        const el = document.getElementById(`edit_${f}`);
        if (el) profile[f] = el.value;
    });
    Store.setProfile(profile);
    const greeting = document.getElementById('greeting-text');
    if (greeting) greeting.textContent = `Olá, ${profile.name || 'Athlete'} 👋`;
    router.updateMenuUserName();
    router.render('perfil');
};

window.toggleCamera = function () {
    if (window.scanner) {
        window.scanner.toggle();
    }
};

window.switchCamera = function () {
    if (window.scanner) {
        window.scanner.switchCamera();
    }
};

window.exportData = function () {
    const data = Store.exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `apex_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
};

window.importData = function (event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
        try {
            const data = JSON.parse(e.target.result);
            Store.importData(data);
            alert('✅ Dados importados com sucesso!');
            location.reload();
        } catch (err) {
            alert('❌ Erro ao importar dados. Arquivo inválido.');
        }
    };
    reader.readAsText(file);
};

// ===================== INIT =====================
document.addEventListener('DOMContentLoaded', function () {
    router = new Router();

    const profile = Store.getProfile();
    if (!profile.name) {
        setTimeout(() => {
            if (confirm('👋 Bem-vindo ao Apex Performance!\n\nVamos criar seu perfil para personalizar sua experiência?')) {
                router.render('perfil');
                setTimeout(editProfile, 300);
            }
        }, 500);
    }
});

console.log('🏋️ Apex Performance - Academia Inteligente');
console.log('📊 Dados armazenados em LocalStorage');
console.log('🔍 Scanner com câmera nativa');

// Fechar menu ao clicar no overlay
document.addEventListener('click', function (e) {
    const overlay = document.getElementById('mobileMenuOverlay');
    if (overlay && overlay.classList.contains('active')) {
        if (e.target === overlay) {
            closeMobileMenu();
        }
    }
});

// Fechar menu ao pressionar ESC
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        closeMobileMenu();
    }
});