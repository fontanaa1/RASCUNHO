# INCLUA — Fundação Supabase (Etapa 2)

Pacote complementar para conectar autenticação, perfis, preferências de acessibilidade e relatos de segurança ao Supabase.

> **Importante sobre a integração:** nesta sessão consegui confirmar os arquivos e metadados do projeto Apex enviado anteriormente e consultar o módulo antigo `supabase.js`, mas o arquivo ZIP original e o pacote INCLUA da etapa anterior não ficaram disponíveis para edição no ambiente (a leitura/materialização do ZIP retornou erro de acesso). Para não sobrescrever nem quebrar componentes existentes, este pacote é entregue como camada complementar. Copie os arquivos para o projeto INCLUA preservando os arquivos atuais e ajuste os imports conforme a estrutura real.

## Conteúdo

- `supabase/migrations/202611240001_inclua_core.sql`: tabelas, enums, gatilho de criação automática de perfil, funções de autorização e políticas RLS.
- `src/services/supabase.ts`: cliente Supabase com validação das variáveis de ambiente.
- `src/services/auth.ts`: login/cadastro por e-mail, OAuth Google, recuperação e atualização de senha, logout e sessão.
- `src/services/profile.ts`: consulta e edição do perfil próprio.
- `src/services/accessibility.ts`: leitura e gravação das preferências de acessibilidade.
- `src/services/safety.ts`: envio e listagem dos relatos de segurança do usuário.

## 1. Aplicar a migração

1. Abra o projeto Supabase correto e confirme que está em ambiente de desenvolvimento.
2. Acesse **SQL Editor → New query**.
3. Cole e execute o conteúdo de `supabase/migrations/202611240001_inclua_core.sql`.
4. Confira em **Table Editor** se existem `profiles`, `accessibility_preferences`, `emergency_contacts` e `safety_reports`.
5. Depois de criar sua conta de administrador pelo fluxo normal de cadastro, execute no SQL Editor o `UPDATE` comentado no final da migração, substituindo pelo e-mail real do administrador. Depois disso, administradores podem alterar papéis chamando `supabase.rpc('admin_set_user_role', { target_user_id, new_role: 'employee' })` ou `new_role: 'admin'`. Não promova usuários por campos de cadastro ou pelo frontend.

Os novos usuários recebem automaticamente `student`. A alteração de `role` pelo próprio usuário é bloqueada no banco. Somente uma conta com papel `admin` pode alterar o papel de outra conta usando a função `admin_set_user_role` (RPC). A coluna `role` não pode ser atualizada diretamente pelo cliente. A promoção inicial deve ser feita no SQL Editor confiável.

## 2. Configurar autenticação

No Supabase, abra **Authentication → Providers**:

- Ative **Email** e escolha se a confirmação de e-mail será obrigatória.
- Ative **Google** e informe o OAuth Client ID e Client Secret obtidos no Google Cloud.
- Em **Authentication → URL Configuration**, configure a URL local e a URL pública do app em Site URL / Redirect URLs.
- Para Android/Capacitor, configure também o deep link nativo e a URL de retorno correspondente antes de usar OAuth no APK. O helper atual usa a origem web; em mobile, adapte `redirectTo` ao esquema/deep link registrado no Capacitor.

## 3. Integrar ao Vite/React

1. Copie `.env.example` para `.env.local` na raiz do projeto.
2. Preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` com a URL e a chave publicável do Supabase.
3. Copie a pasta `src/services` para `src/services` do projeto (faça merge, não substitua a pasta inteira).
4. Instale, se ainda não existir: `npm install @supabase/supabase-js`.
5. Importe as funções necessárias nos componentes de login, perfil, acessibilidade e segurança.
6. Reinicie o Vite após alterar `.env.local`.

Exemplo:

```ts
import { signInWithEmail, signInWithGoogle } from './services/auth';

await signInWithEmail(email, password);
// ou
await signInWithGoogle();
```

## 4. Modelo de dados e acesso

| Tabela | Uso | Acesso |
|---|---|---|
| `profiles` | dados básicos e papel `student`, `employee`, `admin` | titular e admin |
| `accessibility_preferences` | contraste, movimento, escala de texto, leitor de tela e preferências de comunicação | titular e admin |
| `emergency_contacts` | contatos de emergência | somente titular |
| `safety_reports` | relatos de assédio, acessibilidade, equipamentos, lesões e conduta | autor acompanha; equipe/admin trata |

RLS está ativado nas quatro tabelas. Não use `service_role` no frontend. A chave `anon`/publicável é a apropriada para o cliente com RLS.

## 5. Testes manuais recomendados

1. Cadastre um usuário novo por e-mail. Confirme que `profiles` e `accessibility_preferences` receberam linhas com `role = student`.
2. Faça login por e-mail e depois teste Google após configurar as credenciais OAuth.
3. Atualize nome/telefone e confirme que o perfil persiste após sair e entrar.
4. Salve preferências de acessibilidade e confirme que outro usuário autenticado não consegue consultá-las.
5. Tente enviar uma denúncia com menos de 10 caracteres: o banco deve rejeitar. Envie um relato válido e confira que o titular consegue vê-lo.
6. Com uma segunda conta comum, tente consultar o relato do primeiro usuário: a consulta deve retornar zero linhas.
7. Tente alterar `profiles.role` do próprio usuário para `admin`: o banco deve rejeitar.
8. Promova uma conta de teste para `employee`/`admin` no SQL Editor e confirme que a equipe consegue consultar e atualizar o status dos relatos.

## Limites desta etapa

- Não foi possível executar a migração no seu projeto Supabase, pois não tenho acesso administrativo ao seu projeto.
- O código foi entregue como módulo de integração; não foi compilado dentro do app INCLUA porque o ZIP de trabalho não estava acessível nesta sessão.
- O fluxo OAuth nativo Android exige configuração de deep link no app e no Supabase antes de ser considerado pronto.
- Este esquema é uma fundação inicial; antes de produção, revise retenção, consentimento, canal de emergência real, política de privacidade e procedimentos humanos de resposta a denúncias.
