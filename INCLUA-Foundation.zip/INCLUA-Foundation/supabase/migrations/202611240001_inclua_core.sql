-- INCLUA | Fundação de dados, perfis, acessibilidade e segurança
-- Execute no SQL Editor do Supabase em um projeto de desenvolvimento primeiro.

begin;

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('student', 'employee', 'admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.safety_report_status as enum ('open', 'in_review', 'resolved', 'dismissed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.safety_report_category as enum ('harassment', 'accessibility', 'equipment', 'injury', 'conduct', 'other');
exception when duplicate_object then null; end $$;

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  avatar_url text,
  role public.app_role not null default 'student',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_full_name_length check (char_length(full_name) <= 120)
);

-- Role nunca pode ser alterada pelo próprio usuário, mesmo que ele tente chamar a API diretamente.
create or replace function public.prevent_self_role_change()
returns trigger language plpgsql set search_path = '' as $$
begin
  if auth.uid() is not null and auth.uid() = old.id and new.role is distinct from old.role then
    raise exception 'Você não pode alterar seu próprio nível de acesso.' using errcode = '42501';
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_prevent_self_role_change on public.profiles;
create trigger profiles_prevent_self_role_change
before update on public.profiles
for each row execute function public.prevent_self_role_change();

create table if not exists public.accessibility_preferences (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  high_contrast boolean not null default false,
  reduce_motion boolean not null default false,
  text_scale smallint not null default 100 check (text_scale between 80 and 160),
  screen_reader_hints boolean not null default true,
  preferred_language text not null default 'pt-BR',
  mobility_notes text,
  communication_preferences text,
  updated_at timestamptz not null default now()
);

create table if not exists public.emergency_contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  contact_name text not null,
  relationship text,
  phone text not null,
  created_at timestamptz not null default now(),
  constraint emergency_contact_name_length check (char_length(contact_name) between 1 and 120)
);

create table if not exists public.safety_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete restrict,
  category public.safety_report_category not null default 'other',
  description text not null,
  location_description text,
  is_anonymous_to_staff boolean not null default false,
  status public.safety_report_status not null default 'open',
  staff_notes text,
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint safety_report_description_length check (char_length(description) between 10 and 5000)
);

create index if not exists safety_reports_status_created_idx on public.safety_reports(status, created_at desc);
create index if not exists safety_reports_reporter_idx on public.safety_reports(reporter_id, created_at desc);

-- Funções SECURITY DEFINER evitam recursão de RLS ao consultar profiles.
create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer set search_path = ''
as $$ select p.role from public.profiles p where p.id = (select auth.uid()) $$;

create or replace function public.is_staff_or_admin()
returns boolean
language sql stable security definer set search_path = ''
as $$ select coalesce(public.current_app_role() in ('employee'::public.app_role, 'admin'::public.app_role), false) $$;

create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = ''
as $$ select coalesce(public.current_app_role() = 'admin'::public.app_role, false) $$;

revoke all on function public.current_app_role() from public;
revoke all on function public.is_staff_or_admin() from public;
revoke all on function public.is_admin() from public;
grant execute on function public.current_app_role() to authenticated;
grant execute on function public.is_staff_or_admin() to authenticated;
grant execute on function public.is_admin() to authenticated;

-- Alteração de papel por administradores: operação explícita, sem expor service_role.
create or replace function public.admin_set_user_role(target_user_id uuid, new_role public.app_role)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not coalesce(public.is_admin(), false) then
    raise exception 'Apenas administradores podem alterar papéis.' using errcode = '42501';
  end if;
  if target_user_id = auth.uid() then
    raise exception 'Use um administrador diferente para alterar seu próprio papel.' using errcode = '42501';
  end if;
  update public.profiles set role = new_role where id = target_user_id;
  if not found then
    raise exception 'Perfil não encontrado.' using errcode = 'P0002';
  end if;
end;
$$;
revoke all on function public.admin_set_user_role(uuid, public.app_role) from public;
grant execute on function public.admin_set_user_role(uuid, public.app_role) to authenticated;

-- Cria automaticamente perfil e preferências quando o Auth cria um usuário.
create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), nullif(new.raw_user_meta_data ->> 'name', ''), split_part(coalesce(new.email, ''), '@', 1)),
    'student'::public.app_role
  ) on conflict (id) do nothing;

  insert into public.accessibility_preferences (user_id)
  values (new.id) on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_inclua on auth.users;
create trigger on_auth_user_created_inclua
after insert on auth.users
for each row execute function public.handle_new_auth_user();

-- Updated_at
 drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();
drop trigger if exists safety_reports_set_updated_at on public.safety_reports;
create trigger safety_reports_set_updated_at before update on public.safety_reports
for each row execute function public.set_updated_at();
drop trigger if exists accessibility_preferences_set_updated_at on public.accessibility_preferences;
create trigger accessibility_preferences_set_updated_at before update on public.accessibility_preferences
for each row execute function public.set_updated_at();

-- RLS
alter table public.profiles enable row level security;
alter table public.accessibility_preferences enable row level security;
alter table public.emergency_contacts enable row level security;
alter table public.safety_reports enable row level security;

-- Profiles: usuário vê/edita o próprio perfil; admin gerencia todos.
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
for select to authenticated using (id = (select auth.uid()) or (select public.is_admin()));
drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin" on public.profiles
for update to authenticated using (id = (select auth.uid()) or (select public.is_admin()))
with check (id = (select auth.uid()) or (select public.is_admin()));

-- Preferências: privadas por padrão, inclusive para funcionários.
drop policy if exists "accessibility_select_own_or_admin" on public.accessibility_preferences;
create policy "accessibility_select_own_or_admin" on public.accessibility_preferences
for select to authenticated using (user_id = (select auth.uid()) or (select public.is_admin()));
drop policy if exists "accessibility_insert_own" on public.accessibility_preferences;
create policy "accessibility_insert_own" on public.accessibility_preferences
for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "accessibility_update_own_or_admin" on public.accessibility_preferences;
create policy "accessibility_update_own_or_admin" on public.accessibility_preferences
for update to authenticated using (user_id = (select auth.uid()) or (select public.is_admin()))
with check (user_id = (select auth.uid()) or (select public.is_admin()));

-- Contatos de emergência: somente o titular pode consultar e manter.
drop policy if exists "emergency_contacts_select_own" on public.emergency_contacts;
create policy "emergency_contacts_select_own" on public.emergency_contacts
for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "emergency_contacts_insert_own" on public.emergency_contacts;
create policy "emergency_contacts_insert_own" on public.emergency_contacts
for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "emergency_contacts_update_own" on public.emergency_contacts;
create policy "emergency_contacts_update_own" on public.emergency_contacts
for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists "emergency_contacts_delete_own" on public.emergency_contacts;
create policy "emergency_contacts_delete_own" on public.emergency_contacts
for delete to authenticated using (user_id = (select auth.uid()));

-- Denúncias: autor acompanha o próprio registro; equipe trata os registros.
drop policy if exists "safety_reports_select_reporter_or_staff" on public.safety_reports;
create policy "safety_reports_select_reporter_or_staff" on public.safety_reports
for select to authenticated using (reporter_id = (select auth.uid()) or (select public.is_staff_or_admin()));
drop policy if exists "safety_reports_insert_as_self" on public.safety_reports;
create policy "safety_reports_insert_as_self" on public.safety_reports
for insert to authenticated with check (reporter_id = (select auth.uid()));
drop policy if exists "safety_reports_update_staff" on public.safety_reports;
create policy "safety_reports_update_staff" on public.safety_reports
for update to authenticated using ((select public.is_staff_or_admin()))
with check ((select public.is_staff_or_admin()));

-- Privilégios explícitos: não conceder acesso anônimo.
revoke all on public.profiles, public.accessibility_preferences, public.emergency_contacts, public.safety_reports from anon;
grant select on public.profiles to authenticated;
grant update (full_name, phone, avatar_url) on public.profiles to authenticated;
grant select, insert, update on public.accessibility_preferences to authenticated;
grant select, insert, update, delete on public.emergency_contacts to authenticated;
grant select on public.safety_reports to authenticated;
grant insert (reporter_id, category, description, location_description, is_anonymous_to_staff) on public.safety_reports to authenticated;
grant update (status, staff_notes, assigned_to) on public.safety_reports to authenticated;

commit;

-- PROMOÇÃO INICIAL DO ADMINISTRADOR (execute separadamente, substituindo o e-mail):
-- update public.profiles p set role = 'admin'
-- from auth.users u where u.id = p.id and u.email = 'SEU_EMAIL@EXEMPLO.COM';
-- Faça isso apenas pelo SQL Editor confiável do projeto. Nunca exponha service_role no app.
