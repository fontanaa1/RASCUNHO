import { requireSupabase } from './supabase';

export type AppRole = 'student' | 'employee' | 'admin';
export type Profile = {
  id: string;
  full_name: string;
  phone: string | null;
  avatar_url: string | null;
  role: AppRole;
  created_at: string;
  updated_at: string;
};

export async function getMyProfile(): Promise<Profile> {
  const client = requireSupabase();
  const { data: userData, error: userError } = await client.auth.getUser();
  if (userError) throw userError;
  if (!userData.user) throw new Error('Faça login para consultar seu perfil.');

  const { data, error } = await client.from('profiles').select('*').eq('id', userData.user.id).single();
  if (error) throw error;
  return data as Profile;
}

export async function updateMyProfile(input: Pick<Profile, 'full_name' | 'phone' | 'avatar_url'>) {
  const client = requireSupabase();
  const { data: userData, error: userError } = await client.auth.getUser();
  if (userError) throw userError;
  if (!userData.user) throw new Error('Faça login para atualizar seu perfil.');

  const { data, error } = await client.from('profiles')
    .update({ full_name: input.full_name, phone: input.phone, avatar_url: input.avatar_url })
    .eq('id', userData.user.id).select('*').single();
  if (error) throw error;
  return data as Profile;
}
