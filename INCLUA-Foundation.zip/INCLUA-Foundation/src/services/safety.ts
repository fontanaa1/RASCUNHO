import { requireSupabase } from './supabase';

export type SafetyCategory = 'harassment' | 'accessibility' | 'equipment' | 'injury' | 'conduct' | 'other';

export async function submitSafetyReport(input: {
  category: SafetyCategory;
  description: string;
  location_description?: string;
  is_anonymous_to_staff?: boolean;
}) {
  const client = requireSupabase();
  const { data: auth, error: authError } = await client.auth.getUser();
  if (authError) throw authError;
  if (!auth.user) throw new Error('Faça login para enviar um relato de segurança.');

  const { data, error } = await client.from('safety_reports').insert({
    ...input,
    reporter_id: auth.user.id,
  }).select('id, category, status, created_at').single();
  if (error) throw error;
  return data;
}

export async function listMySafetyReports() {
  const client = requireSupabase();
  const { data, error } = await client.from('safety_reports')
    .select('id, category, description, location_description, status, created_at, updated_at')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}
