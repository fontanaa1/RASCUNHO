import { requireSupabase } from './supabase';

export type AccessibilityPreferences = {
  high_contrast: boolean;
  reduce_motion: boolean;
  text_scale: number;
  screen_reader_hints: boolean;
  preferred_language: string;
  mobility_notes: string | null;
  communication_preferences: string | null;
};

export async function getAccessibilityPreferences() {
  const client = requireSupabase();
  const { data: auth, error: authError } = await client.auth.getUser();
  if (authError) throw authError;
  if (!auth.user) throw new Error('Faça login para consultar as preferências.');
  const { data, error } = await client.from('accessibility_preferences')
    .select('*').eq('user_id', auth.user.id).single();
  if (error) throw error;
  return data as AccessibilityPreferences;
}

export async function saveAccessibilityPreferences(input: AccessibilityPreferences) {
  const client = requireSupabase();
  const { data: auth, error: authError } = await client.auth.getUser();
  if (authError) throw authError;
  if (!auth.user) throw new Error('Faça login para salvar as preferências.');
  const { data, error } = await client.from('accessibility_preferences')
    .upsert({ ...input, user_id: auth.user.id }, { onConflict: 'user_id' })
    .select('*').single();
  if (error) throw error;
  return data as AccessibilityPreferences;
}
